<?php
session_start();
if (!isset($_SESSION["username"])) {
    echo "<script type='text/javascript'> alert('You have to login first !');
            document.location='signin.php'</script>";
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-sacle=1.0">
    <title>Profile Info</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="update_profile.css" />

</head>

<body>
    <header class="header" id="header">
        <nav class="nav_container">
            <a href="#" class="nav_logo">
                <i class="fa-solid fa-location-arrow"></i>GuideBuddy
            </a>
            <div class="nav_menu" id="nav-menu">
                <ul class="nav_list">
                    <li class="nav_item">
                        <a href="main_pg.php" class="nav_links">Home</a>
                    </li>
                    <li class="nav_item">
                        <a href="profile.php" class="nav_links">Profile</a>
                    </li>
                    <li class="nav_item">
                        <a href="features.php" class="nav_links">Features </a>
                    </li>
                    <li class="nav_item">
                        <a href="contact.php" class="nav_links">Contact Us</a>
                    </li>
                    <li class="nav_item">
                        <a href="logout.php" class="nav_links">Logout</a>
                    </li>
                </ul>
                <!--Close button-->
                <div class="nav_close" id="nav-close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
            </div>

            <!--Toggle button-->
            <div class="nav_toggle" id="nav-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
        </nav>
    </header>
    <br>
    <br>


    <?php
    include ("config.php");
    //session_start();
    if (isset($_SESSION['username'])) {
        $username = $_SESSION['username'];
        $pp = "Select * from records where Username= '$username'";
        $result = $conn->query($pp);
        //echo "<table>";
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $user = $row["Username"];
                //$mail = $row["Email"];
                $pass = $row["Password"];
                $usr_img = $row["Image"];
            }
        }
    }
    ?>
    <div class="container">


        <form method="POST" action="update_records.php" class="update-profile-form" target="_self">
            <div class="form first">
                <div class="details personal">
                    <div class="img">
                        <div class="userimg">
                            <img src="<?php echo $usr_img; ?>" alt="User Image">
                        </div>
                        <div class="upload_img">
                            <input type='file' id='usr_img' name='usr_img' accept='image/*'>
                        </div>
                    </div>
                    <br>
                    <br>
                    <div class="fields">
                        <div class="input-field">
                            <label>Username</label>
                            <input type="text" name="user" value="<?php echo $user; ?>" readonly id="user">
                        </div>
                        <span id="usererr" style="color:red;"></span>

                        <!--<div class="input-field">
                            <label>Email</label>
                            <input type="email" name="mail" value="<?php echo $mail; ?>" readonly>
                        </div>-->
                        <div class="input-field">
                            <label> New Password</label>
                            <input type="password" name="npass" id="npass">
                        </div>
                        <div class="input-field">
                            <label>Full Name</label>
                            <input type="text" name="fname" id="fname">
                        </div>
                        <div class="input-field">
                            <label>Address</label>
                            <input type="text" name="address" id="address">
                        </div>
                        <!--<div class="input-field">
                            <label>Upload Image</label>
                            <input type="file" id="user_pic" name="user_pic">
                        </div>-->
                        <div class="choose">
                            <label>Gender</label>
                            <input type="radio" name="gender" id="male" value="Male">Male
                            <input type="radio" name="gender" id="female" value="Female">Female
                            <input type="radio" name="gender" id="others" value="Others">Others
                        </div>

                        <div class="input-field1">
                            <label>Age</label>
                            <input type="number" name="age" id="age" min="12" max="60">
                        </div>
                    </div>
                </div>
                <center>
                    <div class="buttons">
                        <!--<button type="submit" name="submit" class="nextBtn">Save
                        </button>-->
                        <input type="submit" class="btn-solid" name="save" value="Save">
                    </div>
            </div>
            </center>

    </div>

    </div>

</body>

</html>