<?php
session_start();
if (!isset($_SESSION["username"])) {
    echo "<script type='text/javascript'> alert('You have to login first !');
            document.location='signin.php'</script>";
}
?>

<html>

<head>
    <link rel="stylesheet" href="maptable.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />


</head>

<body>
    <header class="header" id="header">
        <nav class="nav_container">
            <a href="#" class="nav_logo">
                <i class="fa-solid fa-location-arrow"></i>GuideBuddy
            </a>
            <div class="nav_menu" id="nav-menu">
                <ul class="nav_list">
                    <li class="nav_item">
                        <a href="main_pg.php" class="nav_links">Home</a>
                    </li>
                    <li class="nav_item">
                        <a href="profile.php" class="nav_links">Profile</a>
                    </li>
                    <li class="nav_item">
                        <a href="features.php" class="nav_links">Features</a>
                    </li>
                    <li class="nav_item">
                        <a href="contact.php" class="nav_links">Contact Us</a>
                    </li>
                    <li class="nav_item">
                        <a href="logout.php" class="nav_links">Logout</a>
                    </li>
                </ul>
                <!--Close button-->
                <div class="nav_close" id="nav-close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
            </div>

            <!--Toggle button-->
            <div class="nav_toggle" id="nav-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
        </nav>
    </header>
    <br>
    <br>
    <!--<div class="file_headings">
        <h2>File Name</h2>
        <i>Description</i>
    </div>-->
    <!--<div class="container">-->
    <?php
    include ("config.php");

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (!empty($_POST["choice1"]) && !empty($_POST["choice1"])) {
            $start1 = $_POST["start"];
            $end1 = $_POST["end"];
            $choice1 = $_POST["choice1"];
            $choice2 = $_POST["choice2"];
            $flag = false;

            $sql1 = "SELECT Node_number from places where Places='$start1'";
            $sql2 = "SELECT Node_number from places where Places='$end1'";
            $result1 = $conn->query($sql1);
            $result2 = $conn->query($sql2);
            if ($result1->num_rows > 0) {
                while ($row = $result1->fetch_assoc()) {
                    $start = $row["Node_number"];
                    //$startloc = $row[""]
                }
            }
            if ($result2->num_rows > 0) {
                while ($row = $result2->fetch_assoc()) {
                    $end = $row["Node_number"];
                }
            }
            //echo $start . ", " . $end . ", " . $start1 . ", " . $end1 . "<br><br>";
            $command = escapeshellcmd("python ./optimize.py $start $end $choice1 $choice2");
            exec($command, $output, $return);
            $len = count($output);
            /*echo '<div class="sub1">';
            echo '<table class="a">';*/
            if ($return == 0) {

                if ($len == 1) {
                    echo "<center>";
                    echo "<h4>No direct path exists for selected transport.<br>Please choose different transport mode</h4>";
                    echo '<div class="img1">';
                    //echo '<img src="magnifier.svg">';
                    echo '</div>';
                    echo '<div class="img2">';
                    echo '<img src="9315312.png">';
                    echo '</div>';
                    echo "</center>";

                } else if ($len > 1) {
                    echo '<div class="container">';
                    $flag = true;
                    if ($choice1 === 'time') {
                        echo '<div class="sub1">';
                        //echo '<table class="a">';
                        foreach ($output as $line) {
                            if (is_numeric($line)) {
                                echo '<div class="sec1">';
                                echo '<div class="border">';
                                echo "<span style='font-weight:550;'>Starting point</span>: &nbsp;" . "<span style='color:blue;'>" . $start1 . "</span><br>";
                                echo "<span style='font-weight:550;'>Ending point</span>: &nbsp;" . "<span style='color:rgb(182, 10, 10);'>" . $end1 . "</span><br>";
                                if ($line < 60) {
                                    echo "<p><span style='font-weight:550;'>Total in-transit time</span> to reach your destination: " . $line . "&nbspmins<br>(This time is approximate and does not consider waiting time)</p><br>";
                                } else {
                                    $hr = $line / 60;
                                    $min = $line % 60;
                                    echo "<p><span style='font-weight:550;'>Total in-transit time</span> to reach your destination: " . $line . $hr . "&nbsphr&nbsp" . $min . "&nbspmins" . "<br>(This time is approximate and does not consider waiting time)</p><br>";
                                    //echo "<p>Total Time to reach your destination: " . $hr . "hr" . $min . "mins" . "</p><br>";
                                }
                                echo '</div>';
                                echo '</div>';

                            } else if ($choice2 == 'bus') {

                                echo '<div class="info">';
                                echo '<div class="innerinfo">';
                                echo "<p style='font-size:1.13rem;color:rgb(6, 6, 163);font-weight:600'>Guide to reach from&nbsp" . $start1 . "&nbspto&nbsp" . $end1 . "</p>";
                                echo "<br>";
                                for ($i = 1; $i < $len - 1; $i += 3) {
                                    if ($i != $len - 1) {
                                        echo "<span style='font-size:1rem;'>";
                                        echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp<span style='font-weight:500;'>" . $output[$i + 3] . "</span>:&nbsp<span style='color:rgb(63, 142, 233);'><b>Bus&nbsp<i class='fa-solid fa-bus'></i></b></span>";
                                        echo "</span>";
                                        echo "<br>";
                                        echo '<div class="contents">';
                                        echo '<div class="sub_sec1">';
                                        echo "<details>";
                                        echo '<summary class="summary1">Available Transit';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 1]));
                                        $avail_ba = rtrim($output[$i + 1], ',');
                                        echo '<p class="avail_content1">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '<div class="sub_sec2">';
                                        echo "<details>";
                                        echo '<summary class="summary2">Intermediate Stops';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 2]));
                                        $avail_ba = rtrim($output[$i + 2], ',');
                                        echo '<p class="avail_content2">';
                                        echo $avail_ba;
                                        //echo "Acharja Jagadish Chandra Bose Institute";
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '</div>';
                                        echo "<br>";

                                    } else if ($i == $len - 1) {
                                        echo "<span style='font-size:1rem;'>";
                                        echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp:&nbsp<span style='font-weight:500;'>" . "<span style='color:Blue;'>Destination</span></span>";
                                        echo "</span>";
                                        echo "<br>";
                                        echo '<div class="contents">';
                                        echo '<div class="sub_sec1">';
                                        echo "<details>";
                                        echo '<summary class="summary1">Available Transit';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 1]));
                                        $avail_ba = rtrim($output[$i + 1], ',');
                                        echo '<p class="avail_content1">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '<div class="sub_sec2">';
                                        echo "<details>";
                                        echo '<summary class="summary2">Intermediate Stops';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 2]));
                                        $avail_ba = rtrim($output[$i + 2], ',');
                                        echo '<p class="avail_content2">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '</div>';
                                        echo "<br>";

                                    }
                                }
                                echo '</div>';
                                echo '</div>';
                                echo '<div class="sub2">';

                                echo "<p align='center'><iframe id='opt_res' src='optmap.php' title='map' height='450' width='600'></ifame></p>";

                                echo '</div>';
                                return;
                            } else if ($choice2 == 'auto') {
                                echo '<div class="info">';
                                echo '<div class="innerinfo">';
                                echo "<p style='font-size:1.13rem;color:rgb(6, 6, 163);font-weight:600'>Guide to reach from&nbsp" . $start1 . "&nbspto&nbsp" . $end1 . "</p>";
                                echo "<br>";
                                for ($i = 1; $i < $len - 1; $i += 3) {
                                    if ($i != $len - 1) {
                                        echo "<span style='font-size:1rem;'>";
                                        echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp<span style='font-weight:500;'>" . $output[$i + 3] . "</span>:&nbsp <span style='color:green;'><b>Auto</b> &nbsp<img src='auto_rickshaw.png' height=20px width=20px;>";
                                        echo "</span>";
                                        echo "<br>";
                                        echo '<div class="contents">';
                                        echo '<div class="sub_sec1">';
                                        echo "<details>";
                                        echo '<summary class="summary1">Available Transit';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 1]));
                                        $avail_ba = rtrim($output[$i + 1], ',');
                                        echo '<p class="avail_content1">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '<div class="sub_sec2">';
                                        echo "<details>";
                                        echo '<summary class="summary2">Intermediate Stops';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 2]));
                                        $avail_ba = rtrim($output[$i + 2], ',');
                                        echo '<p class="avail_content2">';
                                        echo $avail_ba;
                                        //echo "Acharja Jagadish Chandra Bose Institute";
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '</div>';
                                        echo "<br>";

                                    } else if ($i == $len - 1) {
                                        echo "<span style='font-size:1rem;'>";
                                        echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp:&nbsp<span style='font-weight:500;'>" . "<span style='color:Blue;'>Destination</span></span>";
                                        echo "</span>";
                                        echo "<br>";
                                        echo '<div class="contents">';
                                        echo '<div class="sub_sec1">';
                                        echo "<details>";
                                        echo '<summary class="summary1">Available Transit';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 1]));
                                        $avail_ba = rtrim($output[$i + 1], ',');
                                        echo '<p class="avail_content1">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '<div class="sub_sec2">';
                                        echo "<details>";
                                        echo '<summary class="summary2">Intermediate Stops';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 2]));
                                        $avail_ba = rtrim($output[$i + 2], ',');
                                        echo '<p class="avail_content2">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '</div>';
                                        echo "<br>";

                                    }
                                }
                                echo '</div>';
                                echo '</div>';
                                echo '<div class="sub2">';

                                echo "<p align='center'><iframe id='opt_res' src='optmap.php' title='map' height='450' width='600'></ifame></p>";

                                echo '</div>';
                                return;
                            }

                        }
                        if ($choice2 == 'any') {
                            echo '<div class="info">';
                            echo '<div class="innerinfo">';
                            echo "<p style='font-size:1.13rem;color:rgb(6, 6, 163);font-weight:600'>Guide to reach from&nbsp" . $start1 . "&nbspto&nbsp" . $end1 . "</p>";
                            echo "<br>";
                            //echo "<table style='table-layout:fixed;'>";
                            for ($i = 1; $i < $len - 1; $i += 4) {
                                if ($i != $i + 4) {
                                    echo "<span style='font-size:1rem;'>";
                                    echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp<span style='font-weight:500;'>" . $output[$i + 4] . "</span>:&nbsp";
                                    echo "</span>";
                                    $val = $output[$i + 1];
                                    //echo "<span style='color:red'>" . $val . "</span>";
                                    if (str_contains($val, 'Bus')) {
                                        echo "<span style='color:rgb(63, 142, 233);'><b>" . $output[$i + 1] . "&nbsp<i class='fa-solid fa-bus'></i></b></span>";
                                    } else {
                                        echo "<span style='color:green;'><b>" . $output[$i + 1] . "</b></span>&nbsp<img src='auto_rickshaw.png' height=20px width=20px;>";
                                    }
                                    echo "<br>";
                                    echo '<div class="contents">';
                                    echo '<div class="sub_sec1">';
                                    echo "<details>";
                                    echo '<summary class="summary1">Available Transit';
                                    echo "</summary>";

                                    $length = count(explode(',', $output[$i + 2]));
                                    $avail_ba = rtrim($output[$i + 2], ',');
                                    echo '<p class="avail_content1">';
                                    echo $avail_ba;
                                    echo '</p>';
                                    echo "</details>";
                                    echo '</div>';
                                    echo '<div class="sub_sec2">';
                                    echo "<details>";
                                    echo '<summary class="summary2">Intermediate Stops';
                                    echo "</summary>";

                                    $length = count(explode(',', $output[$i + 3]));
                                    $avail_ba = rtrim($output[$i + 3], ',');
                                    echo '<p class="avail_content2">';
                                    echo $avail_ba;
                                    echo '</p>';
                                    echo "</details>";
                                    echo '</div>';
                                    echo '</div>';
                                    echo "<br>";
                                }
                            }
                            echo '</div>';
                            echo '</div>';
                            //echo "</table>";
                        }
                        //echo '</table>';
                        echo '</div>';

                    } else if ($choice1 === 'cost') {
                        echo '<div class="sub1">';
                        //echo '<table class="a">';
                        foreach ($output as $line) {
                            if (is_numeric($line)) {
                                echo '<div class="sec1">';
                                echo '<div class="border">';
                                echo "<span style='font-weight:550;'>Starting point</span>: &nbsp;" . "<span style='color:blue;'>" . $start1 . "</span><br>";
                                echo "<span style='font-weight:550;'>Ending point</span>: &nbsp;" . "<span style='color:rgb(182, 10, 10);'>" . $end1 . "</span><br>";
                                echo "<p><span style='font-weight:550;'>Total cost</span> to reach your destination: Rs. " . $line . "/-</p><br>";

                                echo '</div>';
                                echo '</div>';

                            } else if ($choice2 == 'bus') {

                                echo '<div class="info2">';
                                echo '<div class="innerinfo2">';
                                echo "<p style='font-size:1.13rem;color:rgb(6, 6, 163);font-weight:600'>Guide to reach from&nbsp" . $start1 . "&nbspto&nbsp" . $end1 . "</p>";
                                echo "<br>";
                                for ($i = 1; $i < $len - 1; $i += 3) {
                                    if ($i != $len - 1) {
                                        echo "<span style='font-size:1rem;'>";
                                        echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp<span style='font-weight:500;'>" . $output[$i + 3] . "</span>:&nbsp<span style='color:rgb(63, 142, 233);'><b>Bus&nbsp<i class='fa-solid fa-bus'></i></b></span>";
                                        echo "</span>";
                                        echo "<br>";
                                        //echo "<tr><td style='word-wrap:break-word;'>style='text-decoration:underline blue;'";
                                        echo '<div class="contents">';
                                        echo '<div class="sub_sec1">';
                                        echo "<details>";
                                        echo '<summary class="summary1">Available Transit';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 1]));
                                        $avail_ba = rtrim($output[$i + 1], ',');
                                        echo '<p class="avail_content1">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '<div class="sub_sec2">';
                                        echo "<details>";
                                        echo '<summary class="summary2">Intermediate Stops';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 2]));
                                        $avail_ba = rtrim($output[$i + 2], ',');
                                        echo '<p class="avail_content2">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '</div>';
                                        echo "<br>";

                                    } else if ($i == $len - 1) {
                                        echo "<span style='font-size:1rem;'>";
                                        echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp:&nbsp<span style='font-weight:500;'>" . "<span style='color:Blue;'>Destination</span></span>";
                                        echo "</span>";
                                        echo "<br>";
                                        echo '<div class="contents">';
                                        echo '<div class="sub_sec1">';
                                        echo "<details>";
                                        echo '<summary class="summary1">Available Transit';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 1]));
                                        $avail_ba = rtrim($output[$i + 1], ',');
                                        echo '<p class="avail_content1">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '<div class="sub_sec2">';
                                        echo "<details>";
                                        echo '<summary class="summary2">Intermediate Stops';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 2]));
                                        $avail_ba = rtrim($output[$i + 2], ',');
                                        echo '<p class="avail_content2">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '</div>';
                                        echo "<br>";
                                        //return;
    
                                    }
                                }
                                echo '</div>';
                                echo '</div>';
                                echo '<div class="sub2">';

                                echo "<p align='center'><iframe id='opt_res' src='optmap.php' title='map' height='450' width='600'></ifame></p>";

                                echo '</div>';
                                return;
                            } else if ($choice2 == 'auto') {
                                echo '<div class="info">';
                                echo '<div class="innerinfo">';
                                echo "<p style='font-size:1.13rem;color:rgb(6, 6, 163);font-weight:600'>Guide to reach from&nbsp" . $start1 . "&nbspto&nbsp" . $end1 . "</p>";
                                echo "<br>";
                                for ($i = 1; $i < $len - 1; $i += 3) {
                                    if ($i != $len - 1) {
                                        echo "<span style='font-size:1rem;'>";
                                        echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp<span style='font-weight:500;'>" . $output[$i + 3] . "</span>:&nbsp <span style='color:green;'><b>Auto</b> &nbsp<img src='auto_rickshaw.png' height=20px width=20px;>";
                                        echo "</span>";
                                        echo "<br>";
                                        echo '<div class="contents">';
                                        echo '<div class="sub_sec1">';
                                        echo "<details>";
                                        echo '<summary class="summary1">Available Transit';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 1]));
                                        $avail_ba = rtrim($output[$i + 1], ',');
                                        echo '<p class="avail_content1">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '<div class="sub_sec2">';
                                        echo "<details>";
                                        echo '<summary class="summary2">Intermediate Stops';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 2]));
                                        $avail_ba = rtrim($output[$i + 2], ',');
                                        echo '<p class="avail_content2">';
                                        echo $avail_ba;
                                        //echo "Acharja Jagadish Chandra Bose Institute";
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '</div>';
                                        echo "<br>";

                                    } else if ($i == $len - 1) {
                                        echo "<span style='font-size:1rem;'>";
                                        echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp:&nbsp<span style='font-weight:500;'>" . "<span style='color:Blue;'>Destination</span></span>";
                                        echo "</span>";
                                        echo "<br>";
                                        echo '<div class="contents">';
                                        echo '<div class="sub_sec1">';
                                        echo "<details>";
                                        echo '<summary class="summary1">Available Transit';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 1]));
                                        $avail_ba = rtrim($output[$i + 1], ',');
                                        echo '<p class="avail_content1">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '<div class="sub_sec2">';
                                        echo "<details>";
                                        echo '<summary class="summary2">Intermediate Stops';
                                        echo "</summary>";

                                        $length = count(explode(',', $output[$i + 2]));
                                        $avail_ba = rtrim($output[$i + 2], ',');
                                        echo '<p class="avail_content2">';
                                        echo $avail_ba;
                                        echo '</p>';
                                        echo "</details>";
                                        echo '</div>';
                                        echo '</div>';
                                        echo "<br>";

                                    }
                                }
                                echo '</div>';
                                echo '</div>';
                                echo '<div class="sub2">';

                                echo "<p align='center'><iframe id='opt_res' src='optmap.php' title='map' height='450' width='600'></ifame></p>";

                                echo '</div>';
                                return;
                            }

                        }
                        if ($choice2 == 'any') {
                            echo '<div class="info2">';
                            echo '<div class="innerinfo2">';
                            echo "<p style='font-size:1.13rem;color:rgb(6, 6, 163);font-weight:600'>Guide to reach from&nbsp" . $start1 . "&nbspto&nbsp" . $end1 . "</p>";
                            echo "<br>";
                            //echo "<table style='table-layout:fixed;'>";
                            for ($i = 1; $i < $len - 1; $i += 4) {
                                if ($i != $i + 4) {
                                    echo "<span style='font-size:1rem;'>";
                                    echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp<span style='font-weight:500;'>" . $output[$i + 4] . "</span>:&nbsp";
                                    echo "</span>";
                                    $val = $output[$i + 1];
                                    //echo "<span style='color:red'>" . $val . "</span>";
                                    if (str_contains($val, 'Bus')) {
                                        echo "<span style='color:rgb(63, 142, 233);'><b>" . $output[$i + 1] . "&nbsp<i class='fa-solid fa-bus'></i></b></span>";
                                    } else {
                                        echo "<span style='color:green;'><b>" . $output[$i + 1] . "</b></span>&nbsp<img src='auto_rickshaw.png' height=20px width=20px;>";
                                    }
                                    echo "<br>";
                                    echo '<div class="contents">';
                                    echo '<div class="sub_sec1">';
                                    echo "<details>";
                                    echo '<summary class="summary1">Available Transit';
                                    echo "</summary>";

                                    $length = count(explode(',', $output[$i + 2]));
                                    $avail_ba = rtrim($output[$i + 2], ',');
                                    echo '<p class="avail_content1">';
                                    echo $avail_ba;
                                    echo '</p>';
                                    echo "</details>";
                                    echo '</div>';
                                    echo '<div class="sub_sec2">';
                                    echo "<details>";
                                    echo '<summary class="summary2">Intermediate Stops';
                                    echo "</summary>";

                                    $length = count(explode(',', $output[$i + 3]));
                                    $avail_ba = rtrim($output[$i + 3], ',');
                                    echo '<p class="avail_content2">';
                                    echo $avail_ba;
                                    echo '</p>';
                                    echo "</details>";
                                    echo '</div>';
                                    echo '</div>';
                                    echo "<br>";
                                }
                            }
                            echo '</div>';
                            echo '</div>';
                            //echo "</table>";
                        }
                        //echo '</table>';
                        echo '</div>';

                    }

                }
            }
            echo '<div class="sub2">';
            if ($flag == TRUE) {
                echo "<iframe id='opt_res' src='optmap.php' title='map' height='450' width='600'></ifame>";
            }
            echo '</div>';
        }
    }
    ?>
</body>


</html>