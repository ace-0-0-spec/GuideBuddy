<?php
session_start();
if (!isset($_SESSION["username"])) {
   echo "<script type='text/javascript'> alert('You have to login first !');
            document.location='signin.php'</script>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
      integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
      crossorigin="anonymous" referrerpolicy="no-referrer" />
   <!--=============== CSS ===============-->
   <link rel="stylesheet" href="stylehome.css">

   <title>Homepage</title>
</head>

<body>
   <header class="header" id="header">
      <nav class="nav_container">
         <a href="#" class="nav_logo">
            <i class="fa-solid fa-location-arrow"></i>GuideBuddy
         </a>
         <div class="nav_menu" id="nav-menu">
            <ul class="nav_list">
               <li class="nav_item">
                  <a href="main_pg.php" class="nav_links">Home</a>
               </li>
               <li class="nav_item">
                  <a href="profile.php" class="nav_links">Profile</a>
               </li>
               <li class="nav_item">
                  <a href="features.php" class="nav_links">Features </a>
               </li>
               <li class="nav_item">
                  <a href="contact.php" class="nav_links">Contact Us</a>
               </li>
               <li class="nav_item">
                  <a href="logout.php" class="nav_links">Logout</a>
               </li>
            </ul>
            <!--Close button-->
            <div class="nav_close" id="nav-close">
               <i class="fa-solid fa-xmark"></i>
            </div>
         </div>

         <!--Toggle button-->
         <div class="nav_toggle" id="nav-toggle">
            <i class="fa-solid fa-bars"></i>
         </div>
      </nav>
   </header>
   <br>
   <br>
   <br>
   <div class="file_heading">
      <h2>User Dashboard</h2>
      <i>Your route guide and navigation buddy for Salt Lake, Kolkata</i>
   </div>
   <div class="container">
      <div class="card__container">
         <article class="card__article">
            <img src="timecost11.png" alt="image" class="card__img">
            <div class="card__data">
               <h2>
                  <a href="optimize_final.php" class="card__title">Optimization</a>
               </h2>
               <p class="card__button">Reach your destination within less time or less money</p>
            </div>
         </article>

         <article class="card__article">
            <img src="map1-logo.png" alt="image" class="card__img">

            <div class="card__data">
               <!--<span class="card__description"></span>-->
               <a href="reco.php" class="card__title">Recommendation</a>
               <p class="card__button">Recommending places that you may like</p>
            </div>
         </article>

         <article class="card__article">
            <img src="transport2.png" alt="image" class="card__img">

            <div class="card__data">
               <!--<span class="card__description">Bojcin Forest, Serbia</span>-->
               <a href="transport.php" class="card__title">Transit Information</a>
               <p href="#" class="card__button">Showing bus or auto route for specific Bus No or Auto lines
               </p>
            </div>
         </article>
      </div>
   </div>
   <script src="mainhm.js"></script>

</body>

</html>