<?php
session_start();
if (!isset($_SESSION["username"])) {
    echo "<script type='text/javascript'> alert('You have to login first !');
            document.location='signin.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Information</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="bus_info.css">
</head>

<body>
    <header class="header" id="header">
        <nav class="nav_container">
            <a href="#" class="nav_logo">
                <i class="fa-solid fa-location-arrow"></i>GuideBuddy
            </a>
            <div class="nav_menu" id="nav-menu">
                <ul class="nav_list">
                    <li class="nav_item">
                        <a href="main_pg.php" class="nav_links">Home</a>
                    </li>
                    <li class="nav_item">
                        <a href="profile.php" class="nav_links">Profile</a>
                    </li>
                    <li class="nav_item">
                        <a href="features.php" class="nav_links">Features </a>
                    </li>
                    <li class="nav_item">
                        <a href="contact.php" class="nav_links">Contact Us</a>
                    </li>
                    <li class="nav_item">
                        <a href="logout.php" class="nav_links">Logout</a>
                    </li>
                </ul>
                <!--Close button-->
                <div class="nav_close" id="nav-close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
            </div>

            <!--Toggle button-->
            <div class="nav_toggle" id="nav-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
        </nav>
    </header>
    <br>
    <br>
    <br>
    <div class="file_heading">
        <h2>Bus Information for Salt Lake, Kolkata</h2>
        <i>Click on the 'Show Map' to view map of any bus route</i>
    </div>
    <div class="main_content">
        <table class="content-table">
            <thead>
                <tr>
                    <th>Bus Name</th>
                    <th>Starts At</th>
                    <th>Ends At</th>
                    <th>Route</th>

                </tr>
            </thead>
            <tbody>
                <center>
                    <?php
                    include ("config.php");
                    $sql = "Select * from bus_info";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {

                        while ($row = $result->fetch_assoc()) {
                            echo "<form action = 'broute.php'method = 'POST' target = '_self'>";
                            $busname = $row["Bus_Route_No"];
                            echo "<tr><td>" . $row["Bus_Route_No"] . "</td><td>" . $row["Starts_at"] . "</td><td>" . $row["Ends_at"] . "</td><td> <button type = 'submit' class ='btn' name = 'bname' value = \"$busname\">Show Map</button></td></tr>";
                            echo "</form>";
                        }


                    } else {
                        echo "<br>0 results";
                    }
                    ?>
                </center>
            </tbody>
        </table>
    </div>
</body>
<script>
    const navMenu = document.getElementById('nav-menu'),
        navToggle = document.getElementById('nav-toggle'),
        navClose = document.getElementById('nav-close')


    /*Validate if constant exists*/
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.add('show-menu')
        })
    }
    if (navClose) {
        navClose.addEventListener('click', () => {
            navMenu.classList.remove('show-menu')
        })
    }

    /*Remove menu mobile*/
    const navLink = document.querySelectorAll('.nav_link')
    function linkAction() {
        const navMenu = document.getElementById('nav-menu')
        navMenu.classList.remove('show-menu')
    }
    navLink.forEach(n => n.addEventListener('click', linkAction))

</script>

</html>