<?php
include ("config.php");
//create table
/*$sql1= "CREATE TABLE Bus_info(Bus_Route_No varchar(50) primary key,Starts_at varchar(50) not null,Ends_at varchar(50) not null)";
   
   if( $conn->query($sql1)=== TRUE){
	   echo "<br>Table created successfully";
   }
   else{
	   echo "Errror creating database: " .$conn->error;
   }
   
$sql2 = "CREATE TABLE Auto_info(Auto_Route_Name varchar(100) primary key)";

if ($conn->query($sql2) === TRUE) {
	echo "<br>Table created successfully";
} else {
	echo "Errror creating database: " . $conn->error;
}



$sql3 = "CREATE TABLE Recommend(Search_key varchar(50) primary key,Place varchar(70) not null,Node_no int not null,Place_type varchar(10),Rating float,Place_address varchar(200),Place_image varchar(50))";

if ($conn->query($sql3) === TRUE) {
	echo "<br>Table created successfully";
} else {
	echo "Error creating database: " . $conn->error;
}


*/
$sql4 = "Create table records(ID INT(10) primary key auto_increment,Username varchar(20),Password varchar(15) not null,Image VARCHAR(50) not null default 'default_avatar.png',Full_Name varchar(50),Address varchar(100),Gender varchar(10),Age INT)";

//$sql4 = "Create table records(ID INT(10) primary key auto_increment,Username varchar(20),Email varchar(50) not null,Password varchar(15) not null,Image VARCHAR(50) not null default 'default_avatar.png',Gender varchar(10),Age INT)";

if ($conn->query($sql4) === TRUE) {
	echo "<br>Table created successfully";
} else {
	echo "Errror creating database: " . $conn->error;
}
$conn->close();
?>