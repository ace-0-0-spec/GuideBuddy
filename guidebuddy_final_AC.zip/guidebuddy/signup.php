<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="style1.css" />
  <title>Sign up Form</title>
</head>

<body>
  <div class="container" id="signUp">
    <div class="forms-container">
      <div class="signin-signup">
        <form method="POST" action="registered.php" class="sign-up-form" target="_self" id="signupForm"
          onsubmit=" return validate()">
          <h2 class="title">Sign up</h2>
          <div class="input-field">
            <i class="fa-solid fa-user"></i>
            <input type="text" placeholder="Username" name="username" id="username" />
          </div>
          <span id="usererr" style="color:red;"></span>
          <!--<div class="input-field">
            <i class="fa-solid fa-envelope"></i>
            <input type="email" placeholder="Email" name="mail" id="mail" />
          </div>
          <span id="mailerr" style="color:red;"></span>-->
          <div class="input-field">
            <i class="fa-solid fa-lock"></i>
            <input type="password" placeholder="Password" name="password" id="password" />
          </div>
          <span id="passerr" style="color:red;"></span>
          <div class="input-field">
            <i class="fa-solid fa-lock"></i>
            <input type="password" placeholder="Confirm Password" name="conf_password" id="conf_password" />
          </div>
          <span id="cpasserr" style="color:red;"></span>
          <input type="submit" class="btn solid" name="signup" value="Signup">
        </form>
      </div>
    </div>

    <div class="panels-container">
      <div class="panel right-panel">
        <div class="content">
          <h3>Welcome back,explorer!</h3>
          <p>
            "Sign in now to continue your journey.Let's pick up where you left off."
          </p>
          <button class="btn transparent" id="sign-in-btn"><a href="signin.php">Sign in</a>
          </button>
        </div>
        <img src="img.svg" class="image" alt="" />
      </div>
    </div>
  </div>
</body>
<script>
  function validate() {
    const form = document.getElementById('signupForm');
    const usernameInput = document.getElementById('username');
    const passwordInput = document.getElementById('password');
    const usernameError = document.getElementById('usererr');
    const passwordError = document.getElementById('passerr');
    //const emailInput = document.getElementById('mail');
    const conf_password = document.getElementById('conf_password');
    //const emailError = document.getElementById('mailerr');
    const conf_passError = document.getElementById('cpasserr');

    // Add event listener to the form submit event
    // form.addEventListener('submit', (e) => {
    //   e.preventDefault(); // Prevent the form from submitting
    let isValid = true;
    // Check if username is blank
    if (usernameInput.value.trim() === '') {
      usernameError.textContent = 'Username is required';
      isValid = false;
    } else if (usernameInput.value.length < 5) {
      usernameError.textContent = 'Username must contain 5 characters';
      isValid = false;
    } else {
      usernameError.textContent = ''; // Clear the error message
    }

    // Check if password is blank
    if (passwordInput.value.trim() === '') {
      passwordError.textContent = 'Password is required';
      isValid = false;
    } else if (passwordInput.value.length < 8 || passwordInput.value.length > 10) {
      passwordError.textContent = 'Length should be 8 to 10 characters';
    } else if ((passwordInput.value.length >= 8 || passwordInput.value.length <= 10)) {

      const passwordRegex = /^[a-zA-Z0-9]+$/;
      if (!passwordRegex.test(passwordInput.value)) {
        passwordError.textContent = 'No special characters are allowed';
        isValid = false;
      } else {
        passwordError.textContent = '';
      }
    }

    /*if (emailInput.value.trim() === '') {
      emailError.textContent = 'Email is required';
      isValid = false;
    } else {
      emailError.textContent = '';
    }*/
    if (conf_password.value.trim() === '') {
      conf_passError.textContent = 'Confirm password is required';
      isValid = false;
    } else if (conf_password.value !== passwordInput.value) {
      conf_passError.textContent = 'Passwords do not match';
      isValid = false;
    } else {
      conf_passError.textContent = '';
    }
    // If both username and password are valid, submit the form

    if (isValid) {
      return true;
    } else {
      return false;
    }

    //  });
  }


</script>

</html>