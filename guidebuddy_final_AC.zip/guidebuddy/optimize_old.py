import sys
import folium  #lib for folium
import networkx as nx  #lib for file to adjlist
from files import nodelist, coordlist, buslist, busroutelist, autolist, autoroutelist, fcoord
from legend_template import template

#change

#i/p

srcname = sys.argv[1]
destname = sys.argv[2]
choice1 = sys.argv[3]
choice2 = sys.argv[4]

key = []

#fetching src and dest id

src = int(srcname)
dest = int(destname)

mapObj = folium.Map(coordlist[src-1], zoom_start=13, width = "96%", height = "96%", left = "2%", top = "2%", TileLayer = "openstreetmap")  #map obj to export
folium.TileLayer('CartoDB Positron', attr='CartoDB Positron').add_to(mapObj)
folium.TileLayer('CartoDB Voyager', attr='CartoDB Voyager').add_to(mapObj)
folium.LayerControl().add_to(mapObj)

folium.Marker(coordlist[src-1],
              tooltip='Start Location',
              popup =  folium.Popup(nodelist[src-1],
                                    max_width = 500),
              icon = folium.Icon(color='purple',
                                 icon_color='white',
                                 prefix='fa',
                                 icon = 'star')
            ).add_to(mapObj)
folium.Marker(coordlist[dest-1],
              tooltip='Destiination',
              popup =  folium.Popup(nodelist[dest-1],
                                                max_width = 500),
              icon = folium.Icon(color='purple',
                                 icon_color='white',
                                 prefix='fa',
                                 icon = 'flag')
            ).add_to(mapObj)

mapObj.save('optmap.html')


#computation

#only bus or only auto
if choice2 == "auto" or choice2 == "bus":
    filename = choice1 + choice2 + '.txt'

    #creating graph
    G=nx.Graph()   #graph
    file = open(filename, 'r').readlines()
    for line in file:
        a, b, w = map(int, line.strip().split(' '))
        G.add_edge(a, b, weight=w)

    #no pref
else:
    #creating graph
    G=nx.MultiGraph()   #graph
    filename = choice1 + "bus.txt"
    file1 = open(filename, 'r').readlines()

    for line in file1:
        a, b, w = map(int, line.strip().split(' '))
        G.add_edge(a, b, weight=w)

    filename = choice1 + "auto.txt"
    file2 = open(filename, 'r').readlines()

    for line in file2:
        a, b, w = map(int, line.strip().split(' '))
        G.add_edge(a, b, key=1, weight=w)

#dijkstra
try:
    path = nx.dijkstra_path(G,src,dest)  #dijkstra path in list
except (nx.NetworkXNoPath, nx.NodeNotFound):
    print("-1")
else:
    tot = nx.dijkstra_path_length(G, src, dest)
    if choice2 == "any":
        edges = nx.utils.pairwise(path)
        key = list(min(G[u][v], key=lambda k: G[u][v][k].get("weight", 1))for u, v in edges)
    
    l = len(path)

    pathlist = []
    transit = []
    for i in range(l):
        pathlist.append(nodelist[path[i]-1])
        if choice2 == "any":
            if i < l-1 and key[i] == 0:
                transit.append('Bus')
            elif i < l-1 and key[i] == 1:
                transit.append('Auto')
    #print(path)
    print(tot)

    if choice1 == "time":

        fullcoordlist = []
        for i in path:
            fullcoordlist.append(fcoord[i-1])
        linelen = l

        finalpath = [path[0]]
        interpath = []
        finaltransit = []

        flag = 0
        first = 0
        print(pathlist[first])

        #for bus
        if choice2 == "bus":
            buses = []
            i = 1
            while i < l:
                #print(path[i])
                interpath.append(pathlist[i-1])
                for j in busroutelist:
                    #print(j)
                    if path[first] in j and path[i] in j:
                        flag = 1
                if flag == 0 and i != l:
                    last = i-1
                    finalpath.append(path[last])
                    for j in busroutelist:
                        if path[first] in j and path[i-1] in j:
                            indx = busroutelist.index(j)
                            if buslist[indx] not in buses:
                                buses.append(buslist[indx])
                    print(*buses, sep = ", ")
                    if first != 0:
                        interpath.pop(0)
                    print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                    print(pathlist[last])
                    buses.clear()
                    interpath.clear()
                    first = last
                    interpath.append(pathlist[first])
                    i = i-1
                elif flag == 1 and i == l-1:
                    finalpath.append(path[i])
                    for j in busroutelist:
                        if path[first] in j and path[i] in j:
                            indx = busroutelist.index(j)
                            if buslist[indx] not in buses:
                                buses.append(buslist[indx])
                    interpath.append(pathlist[i])
                    print(*buses, sep = ", ")
                    if first != 0:
                        interpath.pop(0)
                    print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                    print(pathlist[i])
                    buses.clear()
                    interpath.clear()
                elif flag == 1 and i != l-1:
                    flag = 0
                i = i+1
            #print(finalpath)

        #for auto
        if choice2 == "auto":
            autos = []
            i = 1
            while i < l:
                #print(path[i])
                interpath.append(pathlist[i-1])
                for j in autoroutelist:
                    #print(j)
                    if path[first] in j and path[i] in j:
                        flag = 1
                if flag == 0 and i != l:
                    last = i-1
                    finalpath.append(path[last])
                    for j in autoroutelist:
                        if path[first] in j and path[i-1] in j:
                            indx = autoroutelist.index(j)
                            if autolist[indx] not in autos:
                                autos.append("Auto ("+autolist[indx]+")")
                    print(*autos, sep = ", ")
                    if first != 0:
                        interpath.pop(0)
                    print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                    print(pathlist[last])
                    autos.clear()
                    interpath.clear()
                    first = last
                    interpath.append(pathlist[first])
                    i = i-1
                elif flag == 1 and i == l-1:
                    finalpath.append(path[i])
                    for j in autoroutelist:
                        if path[first] in j and path[i] in j:
                            indx = autoroutelist.index(j)
                            if autolist[indx] not in autos:
                                autos.append("Auto ("+autolist[indx]+")")
                    interpath.append(pathlist[i])
                    print(*autos, sep = ", ")
                    if first != 0:
                        interpath.pop(0)
                    print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                    print(pathlist[i])
                    autos.clear()
                    interpath.clear()
                elif flag == 1 and i != l-1:
                    flag = 0
                i = i+1
            #print(finalpath)

        #for any
        if choice2 == "any":
            busauto = []
            i = 1
            while i < l:
                interpath.append(pathlist[i-1])
                if transit[i-1] == "Bus":
                    transitlist = buslist
                    transitroutelist = busroutelist
                else:
                    transitlist = autolist
                    transitroutelist = autoroutelist
                for j in transitroutelist:
                    if path[first] in j and path[i] in j and transit[first] == transit[i-1]:
                        flag = 1
                if flag == 0 and i != l:
                    last = i-1
                    if transit[last-1] == "Bus":
                        transitlist = buslist
                        transitroutelist = busroutelist
                    else:
                        transitlist = autolist
                        transitroutelist = autoroutelist
                    finalpath.append(path[last])
                    for j in transitroutelist:
                        if path[first] in j and path[i-1] in j:
                            indx = transitroutelist.index(j)
                            if transitlist[indx] not in busauto:
                                if transit[last-1] == "Auto":
                                    busauto.append("Auto ("+transitlist[indx]+")")
                                else:
                                    busauto.append(transitlist[indx])
                    print(transit[last-1])
                    finaltransit.append(transit[last-1])
                    print(*busauto, sep = ", ")
                    if first != 0:
                        interpath.pop(0)
                    print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                    print(pathlist[last])
                    busauto.clear()
                    interpath.clear()
                    first = last
                    interpath.append(pathlist[first])
                    i = i-1
                elif flag == 1 and i == l-1:
                    if transit[i-1] == "Bus":
                        transitlist = buslist
                        transitroutelist = busroutelist
                    else:
                        transitlist = autolist
                        transitroutelist = autoroutelist
                    finalpath.append(path[i])
                    for j in transitroutelist:
                        if path[first] in j and path[i] in j:
                            indx = transitroutelist.index(j)
                            if transitlist[indx] not in busauto:
                                if transit[i-1] == "Auto":
                                    busauto.append("Auto ("+transitlist[indx]+")")
                                else:
                                    busauto.append(transitlist[indx])
                    interpath.append(pathlist[i])
                    print(transit[i-1])
                    finaltransit.append(transit[i-1])
                    print(*busauto, sep = ", ")
                    if first != 0:
                        interpath.pop(0)
                    print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                    print(pathlist[i])
                    busauto.clear()
                    interpath.clear()
                elif flag == 1 and i != l-1:
                    flag = 0
                i = i+1

    if choice1 == "cost":

        fullpath = []

        finalpath = path
        finaltransit = transit
        if choice2 == "bus":
            buses = []
            interpath = []
            for i in range(l-1):
                print(pathlist[i])
                temp = 999
                startindx = -1
                endindx = -1
                busindx = -1
                for j in busroutelist:
                    if path[i] in j and path[i+1] in j:
                        indx = busroutelist.index(j)
                        if buslist[indx] not in buses:
                            buses.append(buslist[indx])
                        indx1 = j.index(path[i])
                        indx2 = j.index(path[i+1])
                        if abs(indx1 - indx2) < temp:
                            temp = abs(indx1 - indx2)
                            startindx = indx1
                            endindx = indx2
                            busindx = indx
                if startindx > endindx:
                    startindx = startindx + 1
                    internodes = busroutelist[busindx][endindx:startindx][::-1]
                else:
                    endindx = endindx + 1
                    internodes = busroutelist[busindx][startindx:endindx]
                    fullpath = internodes
                    fullpath.pop()

                for k in internodes:
                    interpath.append(nodelist[k-1])
                print(*buses, sep = ", ")
                #print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                print(*interpath, sep = " TO ")
                buses.clear()
                interpath.clear()
            print(pathlist[l-1])

        if choice2 == "auto":
            autos = []
            interpath = []
            for i in range(l-1):
                print(pathlist[i])
                temp = 999
                startindx = -1
                endindx = -1
                autoindx = -1
                for j in autoroutelist:
                    if path[i] in j and path[i+1] in j:
                        indx = autoroutelist.index(j)
                        if autolist[indx] not in autos:
                            autos.append("Auto ("+autolist[indx]+")")
                        indx1 = j.index(path[i])
                        indx2 = j.index(path[i+1])
                        if abs(indx1 - indx2) < temp:
                            temp = abs(indx1 - indx2)
                            startindx = indx1
                            endindx = indx2
                            autoindx = indx
                if startindx > endindx:
                    startindx = startindx + 1
                    internodes = autoroutelist[autoindx][endindx:startindx][::-1]
                else:
                    endindx = endindx + 1
                    internodes = autoroutelist[autoindx][startindx:endindx]
                for k in internodes:
                    interpath.append(nodelist[k-1])
                    fullpath = internodes
                    fullpath.pop()
                print(*autos, sep = ", ")
                #print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                print(*interpath, sep = " TO ")
                autos.clear()
                interpath.clear()
            print(pathlist[l-1])
        
        if choice2 == "any":
            busauto = []
            interpath = []

            for i in range(l-1):
                print(pathlist[i])
                print(transit[i])
                temp = 999
                startindx = -1
                endindx = -1
                transitindx = -1
                if transit[i] == "Bus":
                    transitlist = buslist
                    transitroutelist = busroutelist
                else:
                    transitlist = autolist
                    transitroutelist = autoroutelist
                for j in transitroutelist:
                    if path[i] in j and path[i+1] in j:
                        indx = transitroutelist.index(j)
                        if transitlist[indx] not in busauto:
                            if transit[i] == "Bus":
                                busauto.append(transitlist[indx])
                            else:
                                busauto.append("Auto ("+transitlist[indx]+")")
                        indx1 = j.index(path[i])
                        indx2 = j.index(path[i+1])
                        if abs(indx1 - indx2) < temp:
                            temp = abs(indx1 - indx2)
                            startindx = indx1
                            endindx = indx2
                            transitindx = indx
                if startindx > endindx:
                    startindx = startindx + 1
                    internodes = transitroutelist[transitindx][endindx:startindx][::-1]
                else:
                    endindx = endindx + 1
                    internodes = transitroutelist[transitindx][startindx:endindx]
                    fullpath = internodes

                    fullpath.pop()
                for k in internodes:
                    interpath.append(nodelist[k-1])
                print(*busauto, sep = ", ")
                #print(*interpath, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")
                print(*interpath, sep = " TO ")
                busauto.clear()
                interpath.clear()
            print(pathlist[l-1])

        fullpath.append(dest)
        linelen = len(fullpath)
        fullcoordlist = []
        fullpathlist = []
        for i in fullpath:
            fullpathlist.append(nodelist[i-1])
            fullcoordlist.append(fcoord[i-1])
        # print("\n\n",fullpath)
        # print(fullpathlist)
        # print(fullcoordlist)

    #print(finalpath)
    #print(finaltransit)
    length = len(finalpath)

    #map creation

    pathcoord = []
    for i in finalpath:
        pathcoord.append(fcoord[i-1])
    #print(pathcoord)
    
    for i in range(length-1):
        if choice2 == "bus":
            folium.Marker(location = pathcoord[i],
                          icon = folium.Icon(color = 'lightblue',
                                             icon_color = 'black',
                                             prefix = 'fa',
                                             icon = 'bus'),
                          popup = folium.Popup(nodelist[finalpath[i]-1],
                                               max_width = 500)
                          ).add_to(mapObj)
        elif choice2 == "auto":
            folium.Marker(location = pathcoord[i],
                          icon = folium.Icon(color = 'green',
                                             icon_color = 'white',
                                             prefix = 'fa',
                                             icon = 'circle'),
                          popup = folium.Popup(nodelist[finalpath[i]-1],
                                               max_width = 500)
                          ).add_to(mapObj)
        elif choice2 == "any":
            if finaltransit[i] == "Bus":
                folium.Marker(location = pathcoord[i],
                              icon = folium.Icon(color='lightblue',
                                                 icon_color='black',
                                                 prefix='fa',
                                                 icon = 'bus'),
                              popup = folium.Popup(nodelist[finalpath[i]-1],
                                                   max_width = 500)
                              ).add_to(mapObj)
                tempcoord = [pathcoord[i],pathcoord[i+1]]
                #drawing line
                folium.PolyLine(locations = tempcoord,
                                color = 'blue',
                                dash_array = '5',
                                opacity = '85',
                                tooltip = 'Bus'
                                ).add_to(mapObj)
                
            if finaltransit[i] == "Auto":
                folium.Marker(location = pathcoord[i],
                              icon = folium.Icon(color='green',
                                                 icon_color='white',
                                                 prefix='fa',
                                                 icon = 'circle'),
                              popup = folium.Popup(nodelist[finalpath[i]-1],
                                                   max_width = 500)
                              ).add_to(mapObj)
                tempcoord = [pathcoord[i],pathcoord[i+1]]
                #drawing line
                folium.PolyLine(locations = tempcoord,
                                color = 'green',
                                dash_array = '5',
                                opacity = '85',
                                tooltip = 'Auto'
                                ).add_to(mapObj)
                
    folium.Marker(location = pathcoord[length-1],
                  tooltip = 'Destination',
                  icon = folium.Icon(color = 'purple',
                                     icon_color = 'white',
                                     prefix = 'fa',
                                     icon = 'flag'),
                  popup = folium.Popup(nodelist[finalpath[length-1]-1],
                                       max_width = 500)
                  ).add_to(mapObj)
    color = ''
    if choice2 != "any":
        if choice2 == "bus":
            col = 'blue'
            tp = 'Bus'
        else:
            col = 'green'
            tp = 'Auto'
        folium.PolyLine(locations = pathcoord,
                        color = col,
                        dash_array = '5',
                        opacity = '85',
                        tooltip = tp,
                        ).add_to(mapObj)
    
    mapObj.get_root().html.add_child(folium.Element(template))
    #save map
    mapObj.save('optmap.html')