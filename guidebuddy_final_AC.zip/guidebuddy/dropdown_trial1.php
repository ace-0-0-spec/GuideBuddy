<?php	
	include("config.php");
	//create table
	$sql= "Select * from places";
	$result=$conn->query($sql);
	
	/*if( $conn->query($sql)=== TRUE){
		echo "<br>Table created successfully";
	}
	else{
		echo "Errror creating database: " .$conn->error;
	}*/
?>

<html>
<head>
</head>
<body>
<header>
<h3>GuideBuddy</h3>
</header>
<select>
<option> Select</option>
<?php
	if($result)
	{
		while($row=$result->fetch_assoc())
		{
			$pname=$row["Places"];
			echo"<option>$pname<br></option>";
		}
	}

?>
</select>
</body>
</html>