<?php
include ("config.php");
$operr = "";
$typerr = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    if (empty($_POST["choice1"]))
        $operr = "<b>*Please select one to optimize*</b>";
    if (empty($_POST["choice2"]))
        $typerr = "<b>*Please select a mode*</b>";
    if ((!empty($_POST["choice1"])) && (!empty($_POST["choice2"]))) {
        include ("optformreq3.php");
    }
}

?>
<!--<?php
include ("config.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["choice1"]))
        echo "<b>*Please select one to optimize*</b>";
}
?>
<?php
include ("config.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (empty($_POST["choice2"]))
        echo "<b>*Please select oa mode*</b>";
}
?>