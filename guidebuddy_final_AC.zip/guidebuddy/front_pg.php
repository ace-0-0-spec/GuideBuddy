<!DOCTYPE html>

<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="styles.css" />

</head>

<body>
  <header class="header" id="header">
    <nav class="nav_container">
      <a href="#" class="nav_logo">
        <i class="fa-solid fa-location-arrow"></i> GuideBuddy
      </a>
      <div class="nav_menu" id="nav-menu">
        <ul class="nav_list">
          <!--<li class="nav_item">
            <a href="#" class="nav_links">Home</a>
          </li>-->
          <li class="nav_item">
            <a href="features.html" class="nav_links">Features</a>
          </li>
          <li class="nav_item">
            <a href="contact.html" class="nav_links">Contact Us</a>
          </li>
        </ul>

        <a href="signin.php" class="nav_button">Login</a>
        <!--Close button-->
        <div class="nav_close" id="nav-close">
          <i class="fa-solid fa-xmark"></i>
        </div>
      </div>

      <!--Toggle button-->
      <div class="nav_toggle" id="nav-toggle">
        <i class="fa-solid fa-bars"></i>
      </div>
    </nav>
  </header>
  <main class="main">
    <section class="home">
      <div class="home_container container">
        <div class="home_content">
          <h3 class="home_subheading">
            EXPLORE,NAVIGATE,DISCOVER
          </h3>
          <h1 class="home_heading">
            <span>
              Welcome To <br>GuideBuddy
            </span>
            <img src="imgs\line.svg" alt="">
          </h1>
          <p class="home_description">
            Start your exploration
            and reach your destination without any worry of time and cost<br>

          </p>

          <a href="signup.php" class="home_button">
            Get Started
          </a>
        </div>
        <div class="home_img">
          <img src="imgs/points-space.svg" alt="" class="home_points">
          <img src="imgs/bubble3.svg" alt="" class="home_fluid">
          <img src="imgs/sparkle1.svg" alt="" class="home_sparkle_1">
          <img src="imgs/sparkles6.svg" alt="" class="home_sparkle_2">
          <img src="imgs/bd.svg" alt="" class="home_bus">

        </div>
      </div>
      <img src="imgs/clouds-1.svg" class="home_wave-1">
      <img src="imgs/clouds-2.svg" class="home_wave-2">
    </section>
  </main>
  <script src="main.js"></script>

</body>

</html>