import sys
import folium  #lib for folium
import networkx as nx  #lib for file to adjlist
from files import nodelist, coordlist

#i/p

srcname = sys.argv[1]
destname = sys.argv[2]
choice1 = sys.argv[3]
choice2 = sys.argv[4]

key = []

#fetching src and dest id

src = int(srcname)
dest = int(destname)

mapObj = folium.Map(coordlist[src-1], zoom_start=17, width = "90%", height = "90%", left = "5%", top = "5%", TileLayer = "openstreetmap")  #map obj to export
folium.TileLayer('CartoDB Positron', attr='CartoDB Positron').add_to(mapObj)
folium.TileLayer('CartoDB Voyager', attr='CartoDB Voyager').add_to(mapObj)
folium.LayerControl().add_to(mapObj)

folium.Marker(coordlist[src-1],
              tooltip='Start Location',
              popup =  folium.Popup(nodelist[src-1],
                                    max_width = 500),
              icon = folium.Icon(color='purple',
                                 icon_color='white',
                                 prefix='fa',
                                 icon = 'star')
            ).add_to(mapObj)
folium.Marker(coordlist[dest-1],
              tooltip='Destiination',
              popup =  folium.Popup(nodelist[dest-1],
                                                max_width = 500),
              icon = folium.Icon(color='purple',
                                 icon_color='white',
                                 prefix='fa',
                                 icon = 'flag')
            ).add_to(mapObj)

mapObj.save('optmap.html')


#computation

#only bus or only auto
if choice2 == "auto" or choice2 == "bus":
    filename = choice1 + choice2 + '.txt'

    #creating graph
    G=nx.Graph()   #graph
    file = open(filename, 'r').readlines()
    for line in file:
        a, b, w = map(int, line.strip().split(' '))
        G.add_edge(a, b, weight=w)

    #no pref
else:
    #creating graph
    G=nx.MultiGraph()   #graph
    filename = choice1 + "bus.txt"
    file1 = open(filename, 'r').readlines()

    for line in file1:
        a, b, w = map(int, line.strip().split(' '))
        G.add_edge(a, b, weight=w)

    filename = choice1 + "auto.txt"
    file2 = open(filename, 'r').readlines()

    for line in file2:
        a, b, w = map(int, line.strip().split(' '))
        G.add_edge(a, b, key=1, weight=w)

#dijkstra
try:
    path = nx.dijkstra_path(G,src,dest)  #dijkstra path in list
except (nx.NetworkXNoPath, nx.NodeNotFound):
    print("-1: No path exists")
else:
    tot = nx.dijkstra_path_length(G, src, dest)
    if choice2 == "any":
        edges = nx.utils.pairwise(path)
        key = list(min(G[u][v], key=lambda k: G[u][v][k].get("weight", 1))for u, v in edges)
    
    l = len(path)
    pathlist = []
    transit = []
    for i in range(l):
        pathlist.append(nodelist[path[i]-1])
        if choice2 == "any":
            if i < l-1 and key[i] == 0:
                transit.append('Bus')
            elif i < l-1 and key[i] == 1:
                transit.append('Auto')
    print(tot)

    if choice2 == "bus" or choice2 == "auto":
        for i in pathlist:
            print(i)
    else:
        for i, j in zip(pathlist, transit):
            print(i,"\n",j)
        print(pathlist[l-1])

    #map creation

    coordf = []   #float coord vals

    for i in range(l):
        lat = float(coordlist[path[i]-1][0])
        lng = float(coordlist[path[i]-1][1])
        coordf.append([lat,lng])  #str to float conversion
    
        #plotting markers
        if i == l-1:
            folium.Marker(location = [lat,lng],
                          tooltip = 'Destination',
                          popup =  folium.Popup(nodelist[dest-1],
                                                max_width = 500),
                          icon = folium.Icon(color='purple',
                                             icon_color='white',
                                             prefix='fa',
                                             icon = 'flag')
                        ).add_to(mapObj)
        else:
            if choice2 == "bus":
                folium.Marker(location = [lat,lng],
                              tooltip = 'Bus',
                              popup =  folium.Popup(nodelist[path[i]-1],
                                                max_width = 500),
                              icon = folium.Icon(color='purple',
                                                 icon_color='white',
                                                 prefix='fa',
                                                 icon = 'bus')
                            ).add_to(mapObj)
            elif choice2 == "auto":
                folium.Marker(location = [lat,lng],
                              tooltip = 'Auto',
                              popup =  folium.Popup(nodelist[path[i]-1],
                                                max_width = 500),
                              icon = folium.Icon(color='purple',
                                                 icon_color='white',
                                                 prefix='fa',
                                                 icon = 'car')
                            ).add_to(mapObj)
            else:
                if key[i] == 0:
                    folium.Marker(location=[lat,lng],
                                  tooltip='Bus',
                                  popup =  folium.Popup(nodelist[path[i]-1],
                                                max_width = 500),
                                  icon = folium.Icon(color='purple',
                                                     icon_color='white',
                                                     prefix='fa',
                                                     icon = 'bus')
                                ).add_to(mapObj)
                else:
                    folium.Marker(location=[lat,lng],
                                  tooltip='Auto',
                                  popup =  folium.Popup(nodelist[path[i]-1],
                                                max_width = 500),
                                  icon = folium.Icon(color='purple',
                                                     icon_color='white',
                                                     prefix='fa',
                                                     icon = 'car')
                                ).add_to(mapObj)

    #plotting lines
    folium.PolyLine(locations=coordf,
                    color = 'blue',
                    dash_array = '5',
                    opacity = '85',
                    tooltip='Transit Route 101'
                    ).add_to(mapObj)
    
    #add text
    
    mapObj.save('optmap.html')
