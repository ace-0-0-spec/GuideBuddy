<?php
session_start();
if (!isset($_SESSION["username"])) {
    echo "<script type='text/javascript'> alert('You have to login first !');
            document.location='signin.php'</script>";
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-sacle=1.0">
    <title>Transit Info</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="transport.css" />

</head>

<body>
    <header class="header" id="header">
        <nav class="nav_container">
            <a href="#" class="nav_logo">
                <i class="fa-solid fa-location-arrow"></i>GuideBuddy
            </a>
            <div class="nav_menu" id="nav-menu">
                <ul class="nav_list">
                    <li class="nav_item">
                        <a href="main_pg.php" class="nav_links">Home</a>
                    </li>
                    <li class="nav_item">
                        <a href="profile.php" class="nav_links">Profile</a>
                    </li>
                    <li class="nav_item">
                        <a href="features.php" class="nav_links">Features</a>
                    </li>
                    <li class="nav_item">
                        <a href="contact.php" class="nav_links">Contact Us</a>
                    </li>
                    <li class="nav_item">
                        <a href="logout.php" class="nav_links">Logout</a>
                    </li>
                </ul>
                <!--Close button-->
                <div class="nav_close" id="nav-close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
            </div>

            <!--Toggle button-->
            <div class="nav_toggle" id="nav-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
        </nav>
    </header>
    <br>
    <br>
    <br>
    <div class="file_heading">
        <h2>Route and Map of Any Transit at Your fingertips</h2>
        <!-- <i>Route and map of any transit at your fingertips</i> -->
    </div>
    <div class="pos_spark">
        <img src="spark2.svg" class="img1">
    </div>
    <div class="pos_glitter">
        <img src="star3.svg" class="img2">
    </div>
    <div class="pos_star">
        <img src="star2.svg" class="img3">
    </div>
    <div class="pos_bus">
        <img src="bus_stops.svg" class="img4">
    </div>
    <div class="container">
        <center>
            <h1 class="heading">Transit Information</h1>
            <p>Choose from the following:</p>
        </center>
        <br>
        <a href="bus_info.php" target="_self"><button class="b-button">Bus</button></a>
        <a href="auto_info.php" target="_self"><button class="a-button">Auto</button></a>
        <br>
        <br>
        <br>
    </div>
</body>
<script>
    const navMenu = document.getElementById('nav-menu'),
        navToggle = document.getElementById('nav-toggle'),
        navClose = document.getElementById('nav-close')


    /*Validate if constant exists*/
    if (navToggle) {
        navToggle.addEventListener('click', () => {
            navMenu.classList.add('show-menu')
        })
    }
    if (navClose) {
        navClose.addEventListener('click', () => {
            navMenu.classList.remove('show-menu')
        })
    }

    /*Remove menu mobile*/
    const navLink = document.querySelectorAll('.nav_link')
    function linkAction() {
        const navMenu = document.getElementById('nav-menu')
        navMenu.classList.remove('show-menu')
    }
    navLink.forEach(n => n.addEventListener('click', linkAction))

</script>

</html>