<?php
session_start();
if (!isset($_SESSION["username"])) {
    echo "<script type='text/javascript'> alert('You have to login first !');
            document.location='signin.php'</script>";
}
?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>
    <link rel="stylesheet" href="broute.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Latest compiled and minified CSS -->
</head>

<body>
    <header class="header" id="header">
        <nav class="nav_container">
            <a href="#" class="nav_logo">
                <i class="fa-solid fa-location-arrow"></i>GuideBuddy
            </a>
            <div class="nav_menu" id="nav-menu">
                <ul class="nav_list">
                    <li class="nav_item">
                        <a href="main_pg.php" class="nav_links">Home</a>
                    </li>
                    <li class="nav_item">
                        <a href="profile.php" class="nav_links">Profile</a>
                    </li>
                    <li class="nav_item">
                        <a href="features.html" class="nav_links">Features </a>
                    </li>
                    <li class="nav_item">
                        <a href="contact.html" class="nav_links">Contact Us</a>
                    </li>
                    <li class="nav_item">
                        <a href="logout.php" class="nav_links">Logout</a>
                    </li>
                </ul>
                <!--Close button-->
                <div class="nav_close" id="nav-close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
            </div>

            <!--Toggle button-->
            <div class="nav_toggle" id="nav-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
        </nav>
    </header>
    <br>
    <br>
    <br>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $aname = $_POST["aname"];
        //echo "<br><br>Auto Name: ".$aname."<br>";
        $command = escapeshellcmd("python ./autoroutemap.py \"$aname\"");
        exec($command, $output, $return);
        $len = count($output);
        echo '<div class="file_heading">';
        echo '<h2>Route for ' . $output[0] . ' Auto</h2>';
        echo '</div>';
        //echo "<br>";
        //echo "<br>$output[0]";
        //print_r($output);
        //echo "<iframe src='busmap.html' height='600' width='1300'></iframe>";
        if ($return == 0) {
            if ($len > 1) {
                echo '<div class="container">';
                echo '<div class="info">';
                echo '<div class="innerinfo">';
                for ($i = 1; $i < $len - 1; $i += 1) {
                    echo "<span style='font-size:1rem;'>";
                    echo '<ul class="list_style">';
                    echo "<li>";
                    echo "<span style='font-weight:500;'>" . $output[$i] . "</span>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp<span style='font-weight:500;'>" . $output[$i + 1] . "</span>";
                    echo "</li>";
                    echo "</ul>";
                    echo "<br>";

                }
                echo '</div>';
                echo '</div>';
                echo '<div class="sec2">';
                echo '<iframe src="automap.html" title="map" height="400" width="600" align="left"></iframe>';
                echo '</div>';

                echo '</div>';
            }
        }
        // include ("busmap.html");
    }
    ?>
</body>

</html>