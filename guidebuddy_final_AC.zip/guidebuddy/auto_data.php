<?php
	include("config.php");

	$sql="INSERT INTO Auto_info (Auto_Route_Name) VALUES ('Chingrighata to SDF More');";
	$sql.="INSERT INTO Auto_info (Auto_Route_Name) VALUES ('Beleghata / Paribesh Bhaban to Tank no. 13');";
	$sql.="INSERT INTO Auto_info (Auto_Route_Name) VALUES ('Webel More to Newtown Bridge Auto stand');";
	$sql.="INSERT INTO Auto_info (Auto_Route_Name) VALUES ('PNB Island to Tank no. 13');";
	$sql.="INSERT INTO Auto_info (Auto_Route_Name) VALUES ('Karunamoyee auto stand to Tank no. 4');";
	$sql.="INSERT INTO Auto_info (Auto_Route_Name) VALUES ('Beleghata / Paribesh Bhaban to Karunamoyee Auto stand');";
	$sql.="INSERT INTO Auto_info (Auto_Route_Name) VALUES ('Ultadanga to Karunamoyee auto stand');";
	$sql.="INSERT INTO Auto_info (Auto_Route_Name) VALUES ('PNB Island to Webel More');";
	

	if($conn->multi_query($sql)===TRUE)
	{
	   echo "RECORD CREATED SUCCESFULLY";
	}	
	else
	{
		echo"Error creating table. ".$conn->error;
	}

	$conn->close();

?>