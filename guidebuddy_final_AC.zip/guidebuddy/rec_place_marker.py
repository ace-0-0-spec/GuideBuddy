import folium
import sys
from files import fcoord

place = int(sys.argv[1])
placename = sys.argv[2]
place_node_no = place-1
place_coord = fcoord[place_node_no]
mapObj = folium.Map(place_coord, zoom_start=14, width = "96%", height = "96%", left = "2%", top = "2%", TileLayer = "openstreetmap")
folium.TileLayer('CartoDB Positron', attr='CartoDB Positron').add_to(mapObj)
folium.TileLayer('CartoDB Voyager', attr='CartoDB Voyager').add_to(mapObj)
folium.LayerControl().add_to(mapObj)
folium.Marker(place_coord,
              tooltip='Destination',
              popup =  folium.Popup(placename,
                                    max_width = 500),
              icon = folium.Icon(color='purple',
                                 icon_color='white',
                                 prefix='fa',
                                 icon = 'star')
            ).add_to(mapObj)
mapObj.save('rec_place.html')