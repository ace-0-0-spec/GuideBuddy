<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="style.css" />
  <title>Sign in Form</title>
</head>

<body>
  <div class="container" id="signIn">
    <div class="forms-container">
      <div class="signin-signup">
        <form method="POST" action="loggedin.php" class="sign-in-form" target="_self" onsubmit="return validateForm()">
          <h2 class="title">Sign in</h2>
          <div class="input-field">
            <i class="fa-solid fa-user"></i>
            <input type="text" placeholder="Username" name="username" id="username" />
          </div>
          <span id="usererr" style="color:red;"></span>
          <div class="input-field">
            <i class="fa-solid fa-lock"></i>
            <input type="password" placeholder="Password" name="password" id="password" />
          </div>
          <span id="passerr" style="color:red;"></span>
          <input type="submit" class="btn solid" name="signin" value="Login">
        </form>
      </div>
    </div>

    <div class="panels-container">
      <div class="panel left-panel">
        <div class="content">
          <h3>New here ?</h3>
          <p>
            "Ready to navigate?Sign up now and unlock the power of maps at your fingertips."
          </p>
          <button class="btn transparent" id="sign-up-btn"><a href="signup.php">
              Sign up</a>
          </button>
        </div>
        <img src="security.svg" class="image" alt="" />
      </div>
    </div>
  </div>
</body>
<script>
  function validateForm() {
    //e.preventDefault();
    const form = document.querySelector('.sign-in-form');
    var username = document.getElementById('username');
    var password = document.getElementById('password');

    if (username.value == "") {
      document.getElementById('usererr').innerHTML = "Username is required";
    }
    if (password.value == "") {
      document.getElementById('passerr').innerHTML = "Password is required";
    }

    if (username.value !== "" && password.value !== "") {
      document.getElementById('usererr').innerHTML = "";
      document.getElementById('passerr').innerHTML = "";
      true;
    } else {
      return false;
    }
  }
</script>

</html>