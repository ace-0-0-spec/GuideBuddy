<?php
include ("config.php");
//create table
$sql = "INSERT INTO places(Node_number,Places) VALUES('1','Science City');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('2','Metropoliton Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('3','Chingrighata Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('4','Chingrighata Crossing');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('5','Loha Pool');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('6','Nicco Park Westside Pavillion');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('7','Nicco Park Super Bowl');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('8','Swasthya Bhawan Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('9','ICAR Fisheries');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('10','Cognizent Office');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('11','SDF More Autostand');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('12','Fire Brigade Sector V');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('13','TCS Delta Park/Ring Road');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('14','Jheel Paar Bus Stop/Institute of Photography');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('15','Godrej Waterside Tower 2');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('16','ST6 Bus Depot');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('17','Webel Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('18','First Gate Bus stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('19','College More Bus Stand');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('20','Jagadish Chandra Bose Research Institute');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('21','Millenium City Bus Stop/IBM');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('22','Wipro Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('23','Rabindra Bharati University');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('24','EE Block');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('25','Tank 10 Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('26','Anandalok Hospital');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('27','Karunamoyee Auto Stand ');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('28','Karunamoyee Bus Stand');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('29','Mayukh Bhawan/Purta Bhawan');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('30','Jalasompad Bhawan');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('31','Bikash Bhavan');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('32','Central Park Metro');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('33','ILS Hospital');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('34','City Center Mall');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('35','Bidhannagar College');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('36','CA Block');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('37','Tank No. 2 ');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('38','PNB Island Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('39','EM Bypass/Ultadanga Traffic Guard');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('40','Ultadanga Bus Terminus');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('41','Beleghata Auto Stand/Paribesh Bhawan');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('42','Sports Authority of India Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('43','AMRI Hospital');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('44','Amul Island/IA Block');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('45','Manipal Hospital/Bigbazar');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('46','Bijan Bhawan');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('47','GD Island Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('48','FD Block');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('49','Swami Vivekananda Island/FD Park');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('50','RS Softwre Bus Stop/ Sidco Global Tower');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('51','Technopolis Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('52','CRPF IGP Office');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('53','Susrut Eye Foundation and Research Center ');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('54','Tank No. 14');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('55','Bidhhannagar South Police Station');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('56','Stadium Gate No. 2');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('57','Tank No. 13');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('58','Teen Kanya Bus Stop/Tank No. 1');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('59','Vidyasar Abasan Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('60','DLF Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('61','No. 3 Island');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('62','Tank No. 4 ');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('63','CRPF Camp Island');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('64','Baishakhi Island');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('65','Tank No. 7');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('66','206 Bus Stop');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('67','8 No Tank/8 No. Island');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('68','Apollo Hospital');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('69','Mani Square Mall');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('70','Bengal Chemical Metro');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('71','Bidhan Sishu Udyan/Bidhan Park');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('72','Tank No. 16');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('73','National Institute of Homeopathy');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('74','Tank No. 12 Bus Stop/GD Bus Terminus');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('75','Matri Sadan Bidhan Hospital');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('76','Stadium Gate No. 1');";
$sql .= "INSERT INTO places(Node_number,Places) VALUES('77','Newtown Bridge Auto Stand');";

if ($conn->multi_query($sql) === TRUE) {
	echo "RECORD CREATED SUCCESFULLY";
} else {
	echo "Error creating table. " . $conn->error;
}

$conn->close();
?>