<html>

<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style2.css">
</head>

<body>
    <div class="svgb">
        <img src="blob.svg" class="blob1_img">
    </div>
    <div class="svgb">
        <img src="blob2.svg" class="blob2_img">
    </div>
    <div class="svgb">
        <img src="blob3.svg" class="blob3_img">
    </div>
    <!--<div class="svgb">
            <img src="blob5.svg" class="bubble_img">
    </div>-->
    <div class="container">
        <center>
            <h1 class="heading">Transit Information</h1>
            <p>Choose from the following</p>
        </center>
        <br>
        <a href="bus_info.php" target="_self"><button class="b-button">Bus</button></a>
        <a href="auto_info.php" target="_self"><button class="a-button">Auto</button></a>
        <br>
        <br>
        <br>
    </div>
</body>

</html>