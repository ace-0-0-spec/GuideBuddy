<?php
include ("config.php");

$sql = "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-12', 'Chingrighata Bus Stop', 'DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-12N','Beleghata Auto Stand/Paribesh Bhawan','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('44A','Ultadanga Bus Terminus','ST6 Bus Depot');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('215A','Godrej Waterside Tower 2','Ultadanga Bus Terminus');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('ST-6','Science City','ST6 Bus Depot');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-30','Ultadanga Bus Terminus','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('215A/1','Ultadanga Bus Terminus','Godrej Waterside Tower 2');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-30S','Ultadanga Bus Terminus/15 no Bus Stand','DLF Bus Stop');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-37','EM Bypass /Ultadanga TRAFFIC GUARD','Science City');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-50A','EM Bypass /Ultadanga TRAFFIC GUARD','Science City');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('KB-16','Ultadanga Bus Terminus','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('260','Ultadanga Bus Terminus','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('K-1','Ultadanga Bus Terminus','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('32A','Ultadanga Bus Terminus','Godrej Waterside Tower 2');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('201','Ultadanga Bus Terminus','Godrej Waterside Tower 2');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('206','Ultadanga Bus Terminus','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('DN-8','Ultadanga Bus Terminus','Godrej Water side Tower 2');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('KB-22','Ultadanga Bus Terminus','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-173','Mayukh Bhawan / Purta Bhawan','Stadium Gate No. 1');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-9','Science City','Karunamoyee Crossing/Bus Stand');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-14','Science City','Karunamoyee Crossing/Bus Stand');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('239','Beleghata Auto Stand/Paribesh Bhawan','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('14A','Beleghata Auto Stand/Paribesh Bhawan','Karunamoyee Bus Stand');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-9','Beleghata Auto Stand/Paribesh Bhawan','Karunamoyee Bus Stand');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-12','Science City','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('BGN (Botanical Garden)','Science City','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-14','Science City','Karunamoyee Bus Stand');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-12NA','Science City','Karunamoyee Bus Stand');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-46','Science City','Karunamoyee Bus Stand');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('S-12E','Beleghata Auto Stand/Paribesh Bhawan','DLF Bus Stop');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-43','DLF Bus Stop','Science City');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('Amrapally Bhagati','206 Bus Stop','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('Barasat Botanical Garden','Science City','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('Sukantanagr-Dulagarh','Loha Pool','DLF Bus Stop');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-4B','Sciency City','DLF Bus Stop');";
$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('DN-46','Millenium City Bus Stop/IBM','DLF Bus Stop');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-4A','ICAR Fisheries','DLF Bus Stop');";
//$sql .= "INSERT INTO Bus_info (Bus_Route_No,Starts_at,Ends_at) VALUES ('AC-9B','ICAR Fisheries','DLF Bus Stop');";


if ($conn->multi_query($sql) === TRUE) {
	echo "RECORD CREATED SUCCESFULLY";
} else {
	echo "Error creating table. " . $conn->error;
}

$conn->close();

?>