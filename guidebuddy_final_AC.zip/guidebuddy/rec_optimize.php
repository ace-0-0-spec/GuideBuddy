<?php
/*session_start();
if (!isset($_SESSION["username"])) {
    echo "<script type='text/javascript'> alert('You have to login first !');
            document.location='signin.php'</script>";
}*/
?>


<?php
include ("config.php");
//create table
$sql = "Select * from places order by Places ASC;";
$result = $conn->query($sql);
$sql1 = "Select * from recommend";
$result1 = $conn->query($sql1);
$dest = $_REQUEST['direction'];
$placename = $_REQUEST['dest'];
$command = escapeshellcmd("python ./rec_place_marker.py $dest \"$placename\"");
exec($command, $output, $return);
?>


<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>
    <link rel="stylesheet" href="search.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

</head>

<body>
    <header class="header" id="header">
        <nav class="nav_container">
            <a href="#" class="nav_logo">
                <i class="fa-solid fa-location-arrow"></i>GuideBuddy
            </a>
            <div class="nav_menu" id="nav-menu">
                <ul class="nav_list">
                    <li class="nav_item">
                        <a href="main_pg.php" class="nav_links">Home</a>
                    </li>
                    <li class="nav_item">
                        <a href="profile.php" class="nav_links">Profile</a>
                    </li>
                    <li class="nav_item">
                        <a href="features.php" class="nav_links">Features </a>
                    </li>
                    <li class="nav_item">
                        <a href="contact.php" class="nav_links">Contact Us</a>
                    </li>
                    <li class="nav_item">
                        <a href="logout.php" class="nav_links">Logout</a>
                    </li>
                </ul>
                <!--Close button-->
                <div class="nav_close" id="nav-close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
            </div>

            <!--Toggle button-->
            <div class="nav_toggle" id="nav-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
        </nav>
    </header>
    <br>
    <br>
    <br>
    <div class="file_heading">
        <h2>Get Directions for <?php echo $placename; ?></h2>
        <i>Optimize route to <?php echo $placename; ?> from any location in Salt Lake, Kolkata</i>
    </div>
    <div class="container_main">
        <div class="svg_img1">
            <img src="loc_blob.svg" class="svg1">
        </div>
        <div class="svg_img2">
            <img src="start_goal_loc.svg" class="svg2">
        </div>
        <form id="form" action="rec_optreq.php" method="POST" target="_self">
            <div class="input-control">
                <label class="strt_loc" for="startlocation"> Start Location</label>
                <select id="startlocation" name="start" required>
                    <option>Select</option>
                    <?php
                    if ($result) {
                        while ($row = $result->fetch_assoc()) {
                            $pname = $row["Places"];
                            echo "<option>$pname<br></option>";
                        }
                    }
                    ?>
                    <div class="droperr"></div>
                </select>
            </div>
            <br>
            <div class="input-control">
                <label class="des" for="destination">Destination</label>
                <!-- <select id="destination" name="end"> -->
                <?php
                // if ($result1) {
                //     while ($row = $result1->fetch_assoc()) {
                //         if($dest==$row['Node_no'])
                //         {
                //             $pname = $row["Place"];
                ?>
                <input id="destination1" name="end1" value="<?php echo $placename; ?>" readonly>
                <input type="hidden" id="destination" name="end" value="<?php echo $dest; ?>">
                <?php
                //         }
                //     }
                // }
                ?>
                <div class="droperr"></div>
                </select>
            </div>
            <br>
            <div class="opt_tc">
                <label class="optm" for="optimize">Optimize</label>
                <div class="time_cost">
                    <input type="radio" id="time" value="time" name="choice1" value="time">
                    <label class="opt_time" for="time">Time</label>
                    <input type="radio" id="cost" value="cost" name="choice1" value="cost">
                    <label class="opt_cost" for="cost">Cost</label>
                </div>
            </div>
            <div class="prefer" id="type">
                <label class="type_prefer" for="type">Type</label>
                <div class="type_options">
                    <input type="radio" id="bus" name="choice2" value="bus">
                    <label class="t_bus" for="bus">Bus</label>
                    <input type="radio" id="auto" name="choice2" value="auto">
                    <label class="t_auto" for="auto">Auto</label>
                    <input type="radio" id="no-preference" name="choice2" value="any">
                    <label class="t_no-prefer" for="no-preference">Any</label>
                </div>
            </div>
            <button id="submit-button" type="submit" value="submit">Submit</button>
        </form>
        <div class="sec2">
            <iframe id="opt_ip" src="rec_place.html" title="map" height="400" width="600"></iframe>
            <?php
            //include ('optmap.html');
            ?>
        </div>
    </div>


    <!--<script>
    function validateForm(e) {
      e.preventDefault();
      const startlocation =document.getElementById("startlocation")
    }
  </script>-->
    <script>
        document.getElementById("form").addEventListener("submit", function (event) {
            event.preventDefault();

            // Validate start location select
            const startLocationSelect = document.getElementById("startlocation");
            if (startLocationSelect.value === "Select") {
                alert("Please select a start location.");
                return;
            }

            // Validate destination select
            const destinationSelect = document.getElementById("destination");
            if (destinationSelect.value === "Select") {
                alert("Please select a destination.");
                return;
            }

            // Validate optimize radio buttons
            const optimizeRadios = document.getElementsByName("choice1");
            let optimizeChecked = false;
            for (let i = 0; i < optimizeRadios.length; i++) {
                if (optimizeRadios[i].checked) {
                    optimizeChecked = true;
                    break;
                }
            }
            if (!optimizeChecked) {
                alert("Please select an option for optimize.");
                return;
            }

            // Validate type radio buttons
            const typeRadios = document.getElementsByName("choice2");
            let typeChecked = false;
            for (let i = 0; i < typeRadios.length; i++) {
                if (typeRadios[i].checked) {
                    typeChecked = true;
                    break;
                }
            }
            if (!typeChecked && document.getElementById("type").style.display !== "none") {
                alert("Please select an option for type.");
                return;
            }

            // If all validations pass, submit the form
            this.submit();
        });
    </script>
</body>

</html>