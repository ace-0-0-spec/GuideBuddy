<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-sacle=1.0">
    <title>Transit Info</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="transit_info.css" />

</head>

<body>
    <div class="sidebar">
        <div class="top">
            <div class="logo">
                <i class="fa-sharp fa-solid fa-location-arrow"></i>
                <span>GuideBuddy</span>
            </div>
            <i class="fa-solid fa-bars" id="bar"></i>
        </div>
        <ul>
            <li>
                <a href="#">
                    <i class="fa-solid fa-user"></i>
                    <span class="nav-item">User</span>
                </a>
                <span class="tooltip">User</span>
            </li>
            <li>
                <a href="#">
                    <i class="fa-solid fa-house"></i>
                    <span class="nav-item">Home</span>
                </a>
                <span class="tooltip">Home</span>
            </li>
            <li>
                <a href="#">
                    <i class="fa-brands fa-gratipay"></i>
                    <span class="nav-item">Recommend</span>
                </a>
                <span class="tooltip">Recommend</span>
            </li>
            <li>
                <a href="#">
                    <i class="fa-solid fa-star"></i>
                    <span class="nav-item">Features</span>
                </a>
                <span class="tooltip">Features</span>
            </li>
            <li>
                <a href="#">
                    <i class="fa-solid fa-gear"></i>
                    <span class="nav-item">Settings</span>
                </a>
                <span class="tooltip">Settings</span>
            </li>
            <li>
                <a href="#">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    <span class="nav-item">Logout</span>
                </a>
                <span class="tooltip">Logout</span>
            </li>
        </ul>
    </div>
    <?php
    include ("transit1.php");
    ?>
</body>
<script>
    let bar = document.querySelector('#bar')
    let sidebar = document.querySelector('.sidebar')

    bar.onclick = function () {
        sidebar.classList.toggle('active');

    };
</script>

</html>