<?php

include ("config.php");
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['signin'])) {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $secure_pass = base64_encode($password);

        $sql = "SELECT * FROM records WHERE Username='$username' and Password='$secure_pass'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            //session_start();
            $row = $result->fetch_assoc();
            $_SESSION['username'] = $row['Username'];
            header("Location: main_pg.php");
            exit();
        } else {

            echo "<script type='text/javascript'> alert('Not Found, Incorrect user or Password');
            document.location='signin.php'</script>";
        }
    }

}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['signup'])) {
        $username = $_POST["username"];
        //$email = $_POST["mail"];
        $password = $_POST["password"];
        $secure_pass = base64_encode($password);
        $checkUser = "SELECT * from records where Username='$username'";
        $result = $conn->query($checkUser);
        if ($result->num_rows > 0) {
            echo "<script type='text/javascript'> alert('Username Already Exists !');
            document.location='signup.php'</script>";

        } else {
            $insertQuery = "INSERT INTO records (Username,Password) VALUES ('$username','$secure_pass')";
            $_SESSION['username'] = $username;
            if ($conn->query($insertQuery) == TRUE) {
                $_SESSION['username'] = $username;
                header("location: main_pg.php");
            } else {
                echo "Error:" . $conn->error;
            }
        }
    }

}
?>