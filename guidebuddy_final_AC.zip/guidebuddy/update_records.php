<?php

include ("config.php");
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['save'])) {
        session_start();
        $username = $_SESSION['username'];
        $npass = $_POST["npass"];
        $secure_npass = base64_encode($npass);
        $profile_img = $_POST["usr_img"];
        $fullname = $_POST["fname"];
        $address = $_POST["address"];
        $gender = $_POST["gender"];
        $age = $_POST["age"];
        $update_db = "SELECT * from records where Username='$username'";
        $result = $conn->query($update_db);
        if ($result->num_rows > 0) {
            if (!empty($fullname)) {
                $updateQuery = "update records set Full_Name='$fullname' where Username='$username'";
                if ($conn->query($updateQuery) == TRUE) {

                    header("location: profile.php");
                } else {
                    echo "Error:" . $conn->error;
                }
            }
            if (!empty($address)) {
                $updateQuery = "update records set Address='$address' where Username='$username'";
                if ($conn->query($updateQuery) == TRUE) {

                    header("location: profile.php");
                } else {
                    echo "Error:" . $conn->error;
                }
            }
            if (!empty($gender)) {
                $updateQuery = "update records set Gender='$gender' where Username='$username'";
                if ($conn->query($updateQuery) == TRUE) {

                    header("location: profile.php");
                } else {
                    echo "Error:" . $conn->error;
                }
            }
            if (!empty($age)) {
                $updateQuery = "update records set Age='$age' where Username='$username'";
                if ($conn->query($updateQuery) == TRUE) {

                    header("location: profile.php");
                } else {
                    echo "Error:" . $conn->error;
                }
            }
            if (!empty($npass)) {
                $updateQuery = "update records set Password='$secure_npass' where Username='$username'";
                if ($conn->query($updateQuery) == TRUE) {

                    header("location: profile.php");
                } else {
                    echo "Error:" . $conn->error;
                }
            }
            if (!empty($profile_img)) {
                $updateQuery = "update records set Image='$profile_img' where Username='$username'";
                if ($conn->query($updateQuery) == TRUE) {

                    header("location: profile.php");
                } else {
                    echo "Error:" . $conn->error;
                }
            }
        }
        //}  !empty($profile_img)
    }

}
?>