<?php
	include("config.php");

    //food
	 $sql="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('tribe+salt+lake', 'Tribe Cafe', 38,'Food', 4.5, 'AB-025, 1st Cross Rd, AB Block, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'tribe.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('altair+capella', 'AltAir Capella', 22,'Food', 4.3, ' Ambuja Neotia EcoCentre, 20th Floor, EM-4, Street No. 13, EM Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091', 'altair.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('motorworks+and+brewing+company', 'Motor Works & Brewing Company', 17,'Food', 4.1, '1st Floor, Street Number 17, EN Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091', 'motorwork.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('gupi+bagha+restaurant+kolkata', 'Gupi Bagha Cafe', 41,'Food', 5.0, 'Ground Floor, CE - 28, Street Number 220, CE Block(Newtown), Action Area I, Newtown, Kolkata, New Town, West Bengal 700156', 'gupibagha.jpeg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('bhooter+raja+dilo+bor+salt+lake', 'Bhooter Raja Dilo Bor', 11,'Food', 4.0, 'Ground Floor, SDF Building, EP Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091', 'bhooter_raja_dilo_bor.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('the+purple+blend+cafe+kolkata', 'The Purple Blend Cafe', 64,'Food', 4.6, '1st Floor, BG-25, near Baisakhi Island, Sector II, Bidhannagar, Kolkata, West Bengal 700091', 'purpleblend_cafe.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('kouzina+mining', 'Kouzina Mining Co.', 61,'Food', 4.2, 'AD 79, AD Block, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'kouzina.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('awesome+restaurant+salt+lake', 'Awesome Restaurant', 56,'Food', 4.2, 'Ia268, IA Block, Sector 3, Bidhannagar, Kolkata, West Bengal 700097', 'awesome_restaurant.jpg');";

    //hospitals
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('manipal+hospital+salt+lake', 'Manipal Hospital', 45, 'Hospital', 4.5, 'IB-193, Broadway Rd, IB Block, Sector 3, Bidhannagar, Kolkata, West Bengal 700106', 'manipal_hospital.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('north+city+hospital+kolkata', 'North City Hospital', 39, 'Hospital', 3.7, '73 & 81B, Bagmari Road, Near Ultadanga Hudco Stop, Kolkata, West Bengal 700054', 'northcity_hospital.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('susrut+eye+hospital+salt+lake', 'Susrut Eye Foundation & Research Centre', 53,'Hospital', 4.2, 'HB-36/A/1, HB Block, Sector 3, Bidhannagar, Kolkata, West Bengal 700106', 'susrut_hospital.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('echs+salt+lake', 'ECHS Polyclininc', 7, 'Hospital', 4.7, 'EM Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091', 'echs_clinic.jpg');";

    //Hotels
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('hotel+monotel+salt+lake', 'Hotel Monotel', 22, 'Hotel', 4.1, '2, Near Wipro Gate No 4, DM Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091', 'monotel.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('the+sonnet+kolkata', 'The Sonnet', 33, 'Hotel', 4.2, 'Plot No. 8, The Sonnet Hotel, DD Block, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'thesonnet.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('the+stadel+salt+lake', 'The Stadel', 43, 'Hotel', 4.2, 'Vivekananda Yuba Bharati Krirangan Gate No.3, Broadway Rd, Sector 3, Bidhannagar, Kolkata, West Bengal 700106', 'thestadel.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('beyzaa', 'Beyzaa Hotel & Suites', 17, 'Hotel', 4.3, 'EN 1, EN Block, Sector V, Saltlake, Kolkata, West Bengal 700091', 'beyzaa.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('the+16+salt+lake', 'The 16', 62, 'Hotel', 4.4, 'BE-16, BE Block, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'the_16.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('vatika+salt+lake+kolkata', 'Om Vatika Guest House', 38, 'Hotel', 4.9, 'AA 40, AA Block, Sec-1, Bidhannagar, Kolkata, West Bengal 700064', 'omvatika.jpg');";

    //Education
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('st.+joan+school+salt+lake+kolkata', 'St. Joan''s', 53, 'Education', 4.3, 'GD-346A, 1st Cross Rd, GD Block, Sector 3, Bidhannagar, Kolkata, West Bengal 700106', 'stjohn.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('iem+public+school+salt+lake', 'IEM Public School', 74, 'Education', 4.6, 'GE 4/A SaltLake Sector 3, Near to Tank No 12 and Opp to NIFT Girls Hostel, Kolkata, West Bengal 700106', 'iem_school.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('university+of+north+bengal+salt+lake', 'University of North Bengal', 33, 'Education', 4.5, 'DD-27/C, Sector 1, Salt Lake, Kolkata, 700064', 'northbengal_uni.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('netaji+subhas+open+university+salt+lake', 'Netaji Subhas Open University, HQ', 33, 'Education', 4.0, 'DD 26, DD Block, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'netajisubhas_uni.jpeg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('bidhannagar+college', 'Bidhannagar College', 35, 'Education', 4.3, 'City Center, 3rd Ave, EB-2, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'bidhannagar_college.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('rabindra+bharati+universit', 'Rabindra Bharati University', 23, 'Education', 4.0, 'Dwarakanath, No 6/4, PK Tagore St, Raja Katra, Singhi Bagan, Jorasanko, Kolkata, West Bengal 700007', 'rabindrabharati_uni.jpeg');";

    //Transport
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('chingrighata+bus+stop', 'Chingrighata Bus Stop', 3, 'Transport', 3.8, 'SH 3, Tangra, Kolkata, West Bengal 700105', 'chingrighata_bus_stop.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('central+park+metro+station', 'Central Park Metro', 32, 'Transport', 4.3, 'DF Block, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'central_park_metro.png');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('ultadanga+bus+terminus', 'Ultadanga Bus Terminus', 40, 'Transport', 4.0, 'Bidhan Nagar Road, Ultadanga, Kolkata, West Bengal 700067', 'ultodanga_busterminus.png');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('bengal+chemical+metro+station', 'Bengal Chemical Metro Station', 70, 'Transport', 4.4, 'Kadapara, Phool Bagan, Kankurgachi, Kolkata, West Bengal 700106', 'bengal_chemical_metro.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('salt+lake+sector-v+metro+station', 'Salt Lake Sector V Metro Station', 22, 'Transport', 4.5, 'CM Block, Sector V, Bidhannagar, West Bengal 700091', 'saltlake_sector5_metro.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('karunamoyee+metro+station', 'Karunamoyee Metro Station', 28, 'Transport', 4.6, 'HCPC+RC5, 3rd Ave, Central Park, Sector 3, Bidhannagar, Kolkata, West Bengal 700064', 'karunamoyee_metro.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('salt+lake+stadium+metro+station', 'Salt Lake Stadium Metro', 68, 'Transport', 4.7, 'GA Block, Sector 3, Bidhannagar, Kolkata, West Bengal 700064', 'saltlake_stadium_metro.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('st6+bus+depot', 'ST6 Bus Depot', 16, 'Transport', 3.7, 'HCHJ+XHX, CM Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091', 'st6_busdepot.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('nabadiganta+bus+terminus', 'Nabadiganta Bus Terminus', 15, 'Transport', 4.1, 'HCGQ+MMP, AQ Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091', 'nabadiganta_busterminus.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('city+center+metro+station', 'City Center Metro Station', 34, 'Transport', 4.6, '20, Bidhan Nagar, EC Block, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'City_centre_metro.jpg');";

    //Entertainment
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('city+center+salt+lake', 'City Center Mall', 34, 'Entertainment', 4.5, 'DC Block, Sector 1, Bidhannagar, Kolkata, West Bengal 700064', 'citycenter.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('mani+square+mall', 'Mani Square Mall', 69, 'Entertainment', 4.5, '164/1 Maniktala Main Road, Eastern Metropolitan Byp Rd, Kolkata, West Bengal 700054', 'manisquare.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('science+city+park+kolkata', 'Science City', 1, 'Entertainment', 4.4, 'JBS Haldane Ave, Mirania Gardens, East Topsia, Topsia, Kolkata, West Bengal 700046', 'science_city.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('nicco+park+kolkata', 'Nicco Park', 6, 'Entertainment', 4.4, 'HM Block, Sector IV, Bidhannagar, Kolkata, West Bengal 700106', 'nicco_park.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('rdb+cinemas+salt+lake', 'RDB Cinemas', 12, 'Entertainmnet', 4.4, 'Plot K And GP 1, Street Number 25, EP Block, Sector V, Bidhannagar, Kolkata, West Bengal 700091', 'rdbcinemas.jpg');";
    $sql.="INSERT INTO Recommend (Search_key, Place, Node_no, Place_type, Rating, Place_address, Place_image) VALUES ('nazrul+tirtha+salt+lake', 'Nazrul Tirtha', 77, 'Entertainment', 4.4, 'Action Area I, Mohishgot, Service Rd, Newtown, New Town, West Bengal 700156', 'nazrul_tirtha.jpg')";

    if($conn->multi_query($sql)===TRUE)
	{
	   echo "RECORD CREATED SUCCESFULLY";
	}
	else
	{
		echo"Error creating table. ".$conn->error;
	}

?>