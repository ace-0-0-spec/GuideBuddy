import csv #csv reading
#filereading

with open('nodes.txt', 'r') as Node:
    nodelist = Node.read().splitlines()   #nodes

with open('coords.csv', 'r') as file:  
    csv_reader = csv.reader(file) 
    coordlist = list(csv_reader)           #nodecoordinates

fcoord = []
for i in coordlist:
    res = [eval(j) for j in i]
    fcoord.append(res)          #float coordinates

with open('busnames.txt', 'r') as Bus:
    buslist = Bus.read().splitlines()  #buses

with open('busroute.csv', 'r') as file:  
    csv_reader = csv.reader(file) 
    busroutelistr = list(csv_reader)           #bus route string

busroutelist = []
for i in busroutelistr:
    res = [eval(j) for j in i]
    #print(res)
    busroutelist.append(res)          #bus route int

with open('autonames.txt', 'r') as Bus:
    autolist = Bus.read().splitlines()  #autos

with open('autoroute.csv', 'r') as file:  
    csv_reader = csv.reader(file) 
    autoroutelistr = list(csv_reader)           #auto route string

autoroutelist = []
for i in autoroutelistr:
    res = [eval(j) for j in i]
    #print(res)
    autoroutelist.append(res)          #bus route int

#print(autoroutelist)