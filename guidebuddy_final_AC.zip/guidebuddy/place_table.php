<?php	
	include("config.php");
	//create table
	$sql= "CREATE TABLE places(Node_number int primary key,Places varchar(70) not null)";
	
	if( $conn->query($sql)=== TRUE){
		echo "<br>Table created successfully";
	}
	else{
		echo "Errror creating database: " .$conn->error;
	}
?>