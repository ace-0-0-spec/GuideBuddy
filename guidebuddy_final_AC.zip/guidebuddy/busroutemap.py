import sys
import folium
from files import nodelist, fcoord, buslist, busroutelist

busname = sys.argv[1]
busno = buslist.index(busname)

coords = []
route = []
path = busroutelist[busno]

print(busname)

for i in path:
    coords.append(fcoord[i-1])
    route.append(nodelist[i-1])
    print(nodelist[i-1])

#print(*route, sep = " <html>&nbsp<i class='fa-solid fa-arrow-right'></i>&nbsp</html> ")

mapObj = folium.Map(coords[0], zoom_start=13, width = "96%", height = "96%", left = "2%", top = "2%", tiles = "OpenStreetMap")  #map obj to export
folium.TileLayer('CartoDB Positron', attr='CartoDB Positron').add_to(mapObj)
folium.TileLayer('CartoDB Voyager', attr='CartoDB Voyager').add_to(mapObj)
folium.LayerControl().add_to(mapObj)

for i in path:

    folium.Marker(fcoord[i-1],
                  tooltip = 'Bus',
                  popup =  folium.Popup(nodelist[i-1],
                                        max_width = 500),
                  icon = folium.Icon(color='purple',
                                     icon_color='white',
                                     prefix='fa',
                                     icon = 'bus')
                ).add_to(mapObj)

folium.PolyLine(locations=coords,
                color = 'blue',
                dash_array = '5',
                opacity = '85',
                tooltip=busname
                ).add_to(mapObj)
mapObj.save('busmap.html')