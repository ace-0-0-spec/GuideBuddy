<?php
session_start();
if (!isset($_SESSION["username"])) {
    echo "<script type='text/javascript'> alert('You have to login first !');
            document.location='signin.php'</script>";
}
?>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Features</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="features.css" />

</head>

<body>
    <header class="header" id="header">
        <nav class="nav_container">
            <a href="#" class="nav_logo">
                <i class="fa-solid fa-location-arrow"></i>GuideBuddy
            </a>
            <div class="nav_menu" id="nav-menu">
                <ul class="nav_list">
                    <li class="nav_item">
                        <a href="main_pg.php" class="nav_links">Home</a>
                    </li>
                    <li class="nav_item">
                        <a href="profile.php" class="nav_links">Profile</a>
                    </li>
                    <li class="nav_item">
                        <a href="features.php" class="nav_links">Features </a>
                    </li>
                    <li class="nav_item">
                        <a href="contact.php" class="nav_links">Contact Us</a>
                    </li>
                    <li class="nav_item">
                        <a href="logout.php" class="nav_links">Logout</a>
                    </li>
                </ul>
                <!--Close button-->
                <div class="nav_close" id="nav-close">
                    <i class="fa-solid fa-xmark"></i>
                </div>
            </div>

            <!--Toggle button-->
            <div class="nav_toggle" id="nav-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
        </nav>
    </header>

    <div class="container">
        <div class=" sub-container heading">
            <div class="bg_style">
                <h2>Features</h2>
            </div>

        </div>
        <img src="18771-logo-bg.png">
        <div class="icon2">
            <img src="feature_icon.svg" class="icon2">
        </div>
        <div class="services">
            <div class="service">
                <h2>Optimize</h2>
                <p>Optimize your route between any two locations and get a transit guide for that route. Minimize
                    your time or cost required to reach a desired destination from any location.</p>
            </div>
            <div class="service">
                <h2>Recommend</h2>
                <p>Get curated recommendations based on Google ratings. Find more information about your place of
                    choice and get optimized route to selected place.</p>
            </div>
            <div class="service">
                <h2>Transit Info</h2>
                <p>Find map and route information about all the available transit in an area. For now our list of
                    transit includes only Bus and Auto</p>
            </div>
        </div>
    </div>
</body>

</html>