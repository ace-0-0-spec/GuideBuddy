<?php
//database creation
$conn = mysqli_connect("localhost", "root", "");
$sql = "CREATE DATABASE Guidebuddy";
if ($conn->query($sql) === TRUE) {
	echo "<br>Database created successfully";
} else {
	echo "Error creating database: " . $conn->error;
}
$conn->close();
?>