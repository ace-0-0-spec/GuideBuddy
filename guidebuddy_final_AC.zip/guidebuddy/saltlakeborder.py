import folium
import os

mapObj = folium.Map(location=[22.582802642191737,88.41482857049306], zoom_start=13, width = "96%", height = "96%", left = "2%", top = "2%", TileLayer = "openstreetmap")
folium.TileLayer('CartoDB Positron', attr='CartoDB Positron').add_to(mapObj)
folium.TileLayer('CartoDB Voyager', attr='CartoDB Voyager').add_to(mapObj)
folium.LayerControl().add_to(mapObj)
'''folium.Marker([22.582802642191737,88.41482857049306],
              tooltip='Start Location',
              popup =  folium.Popup('marker',
                                    max_width = 500),
              icon = folium.Icon(color='purple',
                                 icon_color='white',
                                 prefix='fa',
                                 icon = 'star')
            ).add_to(mapObj)'''
coordinates = [
                    [
                        22.592114796087245,
                        88.394815336296
                    ],
                    [
                        22.58441576923832,
                        88.39926230395054
                    ],
                    [
                        22.580235806563294,
                        88.40084845492794
                    ],
                    [
                        22.571069180650497,
                        88.40386855756645
                    ],
                    [
                        22.56212081254533,
                        88.40815693775227
                    ],
                    [
                        22.558600510114886,
                        88.4106191248573
                    ],
                    [
                        22.557867084430697,
                        88.41268412286149
                    ],
                    [
                        22.57326866786171,
                        88.42094437669778
                    ],
                    [
                        22.567841773019083,
                        88.43277818099523
                    ],
                    [
                        22.567107018980252,
                        88.43611611549522
                    ],
                    [
                        22.576421718144957,
                        88.43969210924195
                    ],
                    [
                        22.576568609227124,
                        88.44072360024279
                    ],
                    [
                        22.57847574922569,
                        88.44167484078991
                    ],
                    [
                        22.580309216151576,
                        88.4381799647752
                    ],
                    [
                        22.582949262105018,
                        88.43325459831937
                    ],
                    [
                        22.58514925399625,
                        88.4359550913436
                    ],
                    [
                        22.60113386402584,
                        88.42467652842339
                    ],
                    [
                        22.603702384878204,
                        88.4133989181608
                    ],
                    [
                        22.592114796087245,
                        88.394815336296
                    ]
                ]
#border = os.path.join(r'map.geojson')
#folium.GeoJson(border, name = 'Salt Lake, Kolkata').add_to(mapObj)
#print(coordinates)
'''BorderLayer = folium.FeatureGroup(name="border")
BorderLayer.add_to(mapObj)
folium.Polygon(coordinates,
               color="darkblue",
               weight=2,
               fill=True,
               fill_color="green",
               fill_opacity=0.3).add_to(BorderLayer)
folium.LayerControl().add_to(mapObj)'''
folium.Polygon(coordinates,
               color="blue",
               weight=2,
               fill=True,
               fill_color="grey",
               fill_opacity=0.3).add_to(mapObj)
mapObj.save('saltlake.html')