<?php

include ("config.php");
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['signin'])) {
        $username = $_POST["username"];
        $password = $_POST["password"];
        $secure_pass = base64_encode($password);

        $sql = "SELECT * FROM records WHERE Username='$username' and Password='$secure_pass'";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
            //session_start();
            $row = $result->fetch_assoc();
            $_SESSION['username'] = $row['Username'];
            header("Location: main_pg.php");
            exit();
        } else {

            echo "<script type='text/javascript'> alert('Not Found, Incorrect user or Password');
            document.location='signin.php'</script>";
        }
    }

}
?>