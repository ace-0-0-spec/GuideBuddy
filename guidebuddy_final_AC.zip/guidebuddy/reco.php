<?php
  // session_start();
  // if (!isset($_SESSION["username"])) {
  //    echo "<script type='text/javascript'> alert('You have to login first !');
  //             document.location='signin.php'</script>";
  // }
?>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Validation</title>
    <link rel="stylesheet" href="recstyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style>

/* .bubble {
background-color:#dd9afd; 
color:white;
padding: 10px 10px 10px 10px;
text-align: center;
text-decoration: none;
display: inline-block;
font-size: 19px;
font-weight:6px;
margin-top: 3px;
margin-left: 4px;
cursor: pointer;
border-radius:24px;
transition-duration: 0.4s;
border-width:1px;
border-color:#a8cdf7;
}

.bubble:hover {
background-color: #adc9ed;
color: white;} */

/* .card {
    
    border: 5px solid #c7c3e6;
    background-color: white;
    width:200px;
    border-radius: 15px;
    margin-top: 15px;
    margin-left:20px;
    margin-right: 5px;
    padding: 9px;
    
    
    } */

    :root {
    --header-height: 3.5rem;
    /*========== Colors ==========*/
    /*Color mode HSL(hue, saturation, lightness)*/

    --text-color: hsl(231, 59%, 32%);
    --second-color: hsl(231, 59%, 32%);



    /*========== Font and typography ==========*/
    /*.5rem = 8px | 1rem = 16px ...*/
    --body-font: "Montserrat", sans-serif;
    --h2-font-size: 1.25rem;
    --font-semi-bold: 600;
    --font-bold: 700;
    --small-font-size: .813rem;
}

    .body{
      padding-top:20px;
      background-color:#c7e9e7;
      font-family: var(--body-font);
      width:100%;
    }

    @media screen and (min-width: 1120px) {
    :root {
        --h2-font-size: 1.5rem;
        --small-font-size: .875rem;
    }
}

    .addcon {
      height:40px;
      width:100%;
      margin-bottom:15px;
      padding:0;
      padding-right:0;
    }

.cardbutton {
  
      padding-top:10px;
      background-color: #dce1f7; 
      color: var(--text-color);
      /* padding: 2px 2px 2px 2px; */
      text-align: center;
      text-decoration: none;
      display: inline-block;
      font-size: 13px;
      padding: 5px 6px 6px 6px;
      font-weight:  8px;
       margin: 4px 2px;
      margin-left: 15px; 
      cursor: pointer;
      border-radius:10px;
      transition-duration: 0.4s;
      border:none;
      border-color:#a2a8d3;
      border-width:1px;
      }
     
      .cardbutton:hover {
        background-color: #a99ee6;
        color: rgb(69, 35, 106);}


.button-container {
  display: flex;
  position: absolute;
  bottom: 0;
  margin-left: 23px;
 /* padding-top:1px;  */
}

.bubble:hover {
        background-color: #a99ee6;
        color: white;}

.bubble {
        background-color:white; 
        color:rgb(61, 52, 126);
        padding: 3px 10px 3px 10px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 19px;
        font-weight:6px;
        margin-top: 1px;
        margin-left: 20px;
        cursor: pointer;
        border-radius:7px;
        transition-duration: 0.4s;
        border-width:2px;
        border-color:#a2a8d3;
        }

        .options{
    /* padding-top:50px; */
    /* padding-left:10px; */
    width: 100%;
    height: 120px;
    /* margin-top: 2px; */
    background-color:white;
    align-content: center;
    margin-bottom:65px;
    margin-left:0;
    position:fixed;
     background-color:#c7e9e7;
    
  }

  .file_heading{
  background-color: #026d5b94;
  padding-bottom : 3px; 
  text-align:center;
  width:flex;
  /* margin-top:2px; */
  color: white;
  margin-bottom:12px;
  height: 65px;
  /* display:flex; */
}

 
  .top{
    position:fixed;
  }

.nav_container {
    /* position: relative; */
    height: var(--header-height);
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: #e4f1d4;
   
  }
  
.rating-container {
  width:70%;
  margin-left: 25px;
  /* background-color:#0087ca; */
 position:absolute;
  bottom:55px;
  height:17px;
  padding-top:1px;
  /* padding-left:20px: */
  padding-bottom:24px;
}

.card {
    
    border: 2px solid #adc9ed;
    background-color: #white;
    /* width:205px; */
    width:270px;
    border-radius: 15px;
    margin-top: 20px;
     margin-left:150px;
    margin-right: 10px; 
    padding: 10px;
    margin-bottom:6px; 
}

.file_heading2{
  /* background-color:#026d5b94; */
  padding-bottom : 1px; 
  text-align:left;
  width:flex;
  padding-top:1px;
  padding-left:50px;
  /* margin: -10; */
  color: white;
  font-size:18px;
  font-style:italic;
  margin-bottom:1px;
  height: 40px;
  margin-top:-20px;
  color:black;
  line-height:10px;
  /* display:flex; */
}



.file_heading h2{
  padding-top:17px;
  font-size:27px;
  padding-bottom:1px;
  line-height:13px;

  /* padding-bottom:2px; */
}
    

img {
  alignment:center;
  height: 130px;
  width: 100%;
}

.container {
    height: 175px;
    width: 250px;
  padding: 1px 1px 1px 1px;
  padding-top:2px;
}
    .nav_list {
      margin-left: auto;
      flex-direction: row;
      column-gap: 4.5rem;
      padding-top:15px;
       font-size:18px;
    }
</style>
</head>

<body>
    <header class="header" id="header">
        <nav class="nav_container">
            <a href="#" class="nav_logo">
                <i class="fa-solid fa-location-arrow"></i>GuideBuddy
            </a>
            <div class="nav_menu" id="nav-menu">
                <ul class="nav_list">
                    <li class="nav_item">
                        <a href="main_pg.php" class="nav_links">Home</a>
                    </li>
                    <li class="nav_item">
                        <a href="profile.php" class="nav_links">Profile</a>
                    </li>
                    <li class="nav_item">
                        <a href="features.php" class="nav_links">Features</a>
                    </li>
                    <li class="nav_item">
                        <a href="contact.php" class="nav_links">Contact Us</a>
                    </li>
                    <li class="nav_item">
                        <a href="logout.php" class="nav_links">Logout</a>
                    </li>
                </ul>
                <!--Close button-->
             <div class="nav_close" id="nav-close">
                    <i class="fa-solid fa-xmark"></i>
             </div>
         </div>

            <!--Toggle button-->
            <div class="nav_toggle" id="nav-toggle">
                <i class="fa-solid fa-bars"></i>
            </div>
            </nav>

   
        
  <!-- <div class="file_heading options"> -->
<nav class="options">
     <div class="file_heading"> 
      <h2>Our Recommended Places</h2>
      <i>For specific type of place choose any of the filtering options below</i>
    </div> 
   
   <form method="post">
    &nbsp;<button type="submit" name="all" class="bubble all">All Places</button>
    &nbsp;<button type="submit" name="food" value="food" class="bubble food">Food</button>
    &nbsp;<button  type="submit" name="hosp" class="bubble hosp">Hospitals & Clinics</button>
    &nbsp;<button type="submit" name="enter" class="bubble enter">Entertainment</button>
    &nbsp;<button type="submit" name="edu" class="bubble edu">Education</button>
    &nbsp;<button type="submit" name="hotel" class="bubble hotel">Hotels</button>
    &nbsp;<button type="submit" name="transport" class="bubble transport">Transport</button>
    <!-- &nbsp;<button type="submit" name="all" class="bubble all">All</button> -->
    <!-- <button type="button" class="btn btn-dark">hhih</button> -->
  </form>
  </nav>
  <!-- </div> -->
<!-- </div>  -->

</header> 


<div class="body">
<br><br><br><br><br><br><br><br>
<center>
<div class="row">

<?php
$counter=0;
$server="localhost";
$user="root";
$password="";
$dbname="GuideBuddy";
$conn1=new mysqli($server,$user,$password,$dbname);
if($conn1->connect_error)
{
die("Failed to connect".$conn1->connect_error);
}


  
   
else if(isset($_REQUEST['hotel']))
{
  ?>
  <div class="file_heading2">
    <i>Results after applying filter for "Hotels": </i>
    <hr style="width:100%;color:black;">
  
  </div>
    <?php
  $sql2="select * from recommend where Place_type = 'Hotel' order by Rating desc;"; 
  $result=$conn1->query($sql2);
  if($result->num_rows>0)
  {
    foreach($result as $key => $val)
    { ?>
     <div class="card col-md-3">
          <img src="<?php echo "images/".$val['Place_image'];  ?>">
              <div class="container">
              <div class="addcon">
              <h5><b><?php echo $val['Place']; ?></b></h5> 
    </div>
              <p style="font-size:11px; line-height:14px;"><?php echo $val['Place_address']; ?></p>
               
              <div class="rating-container">
               <p style="font-size:15px; line-height:16px;"><?php echo "Rating: ".$val['Rating']; ?></p>
                </div>
              
              <div class="button-container">
                <form action="gsearch.php" method="post"> 
               <button type="submit" class="cardbutton" name="serkey" value="<?php echo $val['Search_key']; ?>">More Info</button>&nbsp;&nbsp;&nbsp;
               </form>
                <form action="rec_optimize.php" method="post">
                  <input type="hidden" name="dest" value="<?php echo $val['Place']; ?>">
                  <button type="submit" class="cardbutton" name="direction" value="<?php echo $val['Node_no']; ?>">Direction</button> 
                 </form>
                </div>
             </div>
      </div>
      <script>
        document.querySelector(".hotel").style.background ="#a99ee6";
        document.querySelector(".hotel").style.text ="white" ;
      </script>
      <?php
    }
  }
}



else if(isset($_REQUEST['transport']))
{
  ?>
  <div class="file_heading2">
    <i>Results after applying filter for "Transport": </i>
    <hr style="width:100%;color:black;">
  
  </div>
    <?php
  $sql2="select * from recommend where Place_type = 'Transport' order by Rating desc;"; 
  $result=$conn1->query($sql2);
  if($result->num_rows>0)
  {
    foreach($result as $key => $val)
    { ?>
     <div class="card col-md-3">
          <img src="<?php echo "images/".$val['Place_image'];  ?>">
              <div class="container">
              <div class="addcon">
              <h5><b><?php echo $val['Place']; ?></b></h5> 
    </div>
              <p style="font-size:11px; line-height:14px;"><?php echo $val['Place_address']; ?></p>
               
              <div class="rating-container">
               <p style="font-size:15px; line-height:16px;"><b><?php echo "Rating: ".$val['Rating']; ?></p><b>
                </div>
              
              <div class="button-container">
                <form action="gsearch.php" method="post"> 
               <button type="submit" class="cardbutton" name="serkey" value="<?php echo $val['Search_key']; ?>">More Info</button>&nbsp;&nbsp;&nbsp;
               </form>
                <form action="rec_optimize.php" method="post">
                  <input type="hidden" name="dest" value="<?php echo $val['Place']; ?>">
                  <button type="submit" class="cardbutton" name="direction" value="<?php echo $val['Node_no']; ?>">Direction</button> 
                 </form>
                </div>
             </div>
      </div>
      <script>
        document.querySelector(".transport").style.background ="#a99ee6";
        document.querySelector(".transport").style.text ="white" ;
      </script>
      <?php
    }
  }
}



else if(isset($_REQUEST['food']))
{
  ?>
  <div class="file_heading2">
    <i>Results after applying filter for "Food":</i>
    <hr style="width:100%;color:black;">
  
  </div>
    <?php
  $sql3="select * from recommend where Place_type = 'Food' order by Rating desc;"; 
  $result=$conn1->query($sql3);
  if($result->num_rows>0)
  {
    foreach($result as $key => $val)
    { ?>
     <div class="card col-md-3">
          <img src="<?php echo "images/".$val['Place_image']; ?>" >
              <div class="container">
              <div class="addcon">
              <h5><b><?php echo $val['Place']; ?></b></h5> 
    </div>
              <p style="font-size:11px; line-height:14px;"><?php echo $val['Place_address']; ?></p>
                
              <div class="rating-container">
               <p style="font-size:15px; line-height:16px;"><?php echo "Rating: ".$val['Rating']; ?></p>
                </div>
              
              <div class="button-container">
                <form action="gsearch.php" method="post"> 
               <button type="submit" class="cardbutton" name="serkey" value="<?php echo $val['Search_key']; ?>">More Info</button>&nbsp;&nbsp;&nbsp;
               </form>
                <form action="rec_optimize.php" method="post">
                  <input type="hidden" name="dest" value="<?php echo $val['Place']; ?>">
                  <button type="submit" class="cardbutton" name="direction" value="<?php echo $val['Node_no']; ?>">Direction</button> 
                 </form>
                </div>
             </div>
      </div>
      <script>
        document.querySelector(".food").style.background ="#a99ee6";
        document.querySelector(".food").style.text ="white" ;
      </script>
      <?php
    }
  }
}

else if(isset($_REQUEST['hosp']))
{
  ?>
  <div class="file_heading2">
    <i>Results after applying filter for "Hospitals & Clinics": </i>
    <hr style="width:100%;color:black;">
  
  </div>
    <?php
  $sql4="select * from recommend where Place_type = 'Hospital' order by Rating desc;"; 
  $result=$conn1->query($sql4);
  if($result->num_rows>0)
  {
    foreach($result as $key => $val)
    { ?>
     <div class="card col-md-3">
          <img src="<?php echo "images/".$val['Place_image'];  ?>" >
              <div class="container">
              <div class="addcon">
              <h5><b><?php echo $val['Place']; ?></b></h5> 
    </div>
              <p style="font-size:11px; line-height:14px;"><?php echo $val['Place_address']; ?></p>
               
              <div class="rating-container">
               <p style="font-size:15px; line-height:16px;"><?php echo "Rating: ".$val['Rating']; ?></p>
                </div>
              
              <div class="button-container">
                <form action="gsearch.php" method="post"> 
                <button type="submit" class="cardbutton" name="serkey" value="<?php echo $val['Search_key']; ?>">More Info</button>&nbsp;&nbsp;&nbsp;
               </form>
                <form action="rec_optimize.php" method="post">
                  <input type="hidden" name="dest" value="<?php echo $val['Place']; ?>">
                  <button type="submit" class="cardbutton" name="direction" value="<?php echo $val['Node_no']; ?>">Direction</button> 
                 </form>
                </div>
             </div>
      </div>
      <script>
        document.querySelector(".hosp").style.background ="#a99ee6";
        document.querySelector(".hosp").style.text ="white" ;
      </script>
      <?php
    }
  }
}

else if(isset($_REQUEST['enter']))
{
  ?>
  <div class="file_heading2">
    <i>Results after applying filter for "Entertainment": </i>
    <hr style="width:100%;color:black;">
  
  </div>
    <?php
  $sql5="select * from recommend where Place_type = 'Entertainm' order by Rating desc;"; 
  $result=$conn1->query($sql5);
  if($result->num_rows>0)
  {
    foreach($result as $key => $val)
    { ?>
     <div class="card col-md-3">
          <img src="<?php echo "images/".$val['Place_image'];  ?>" >
              <div class="container">
              <div class="addcon">
                <h5><b><?php echo $val['Place']; ?></b></h5> 
    </div>
                <p style="font-size:11px; line-height:14px;"><?php echo $val['Place_address']; ?></p>
                
                <div class="rating-container">
               <p style="font-size:15px; line-height:16px;"><?php echo "Rating: ".$val['Rating']; ?></p>
                </div>
                
                <div class="button-container">
                <form action="gsearch.php" method="post"> 
               <button type="submit" class="cardbutton" name="serkey" value="<?php echo $val['Search_key']; ?>">More Info</button>&nbsp;&nbsp;&nbsp;
               </form>
                <form action="rec_optimize.php" method="post">
                  <input type="hidden" name="dest" value="<?php echo $val['Place']; ?>">
                  <button type="submit" class="cardbutton" name="direction" value="<?php echo $val['Node_no']; ?>">Direction</button> 
                 </form>
                </div>
             </div>
      </div>
      <script>
        document.querySelector(".enter").style.background ="#a99ee6";
        document.querySelector(".enter").style.text ="white" ;
      </script>
      <?php
    }
  }
}

else if(isset($_REQUEST['edu']))
{
  ?>
<div class="file_heading2">
  <i>Results after applying filter for "Education":</i>
  <hr style="width:100%;color:black;">

</div>
  <?php
  $sql6="select * from recommend where Place_type = 'Education' order by Rating desc;"; 
  $result=$conn1->query($sql6);
  if($result->num_rows>0)
  {
    foreach($result as $key => $val)
    { ?>
     <div class="card col-md-3">
          <img src="<?php echo "images/".$val['Place_image']; ?>" >
              <div class="container">
              <div class="addcon">
                <h5><b><?php echo $val['Place']; ?></b></h5> 
    </div>
                <p style="font-size:11px; line-height:14px;"><?php echo $val['Place_address']; ?></p>
                
                <div class="rating-container">
               <p style="font-size:15px; line-height:16px;"><?php echo "Rating: ".$val['Rating']; ?></p>
                </div>

                <div class="button-container">
                <form action="gsearch.php" method="post"> 
               <button type="submit" class="cardbutton" name="serkey" value="<?php echo $val['Search_key']; ?>">More Info</button>&nbsp;&nbsp;&nbsp;
               </form>
                <form action="rec_optimize.php" method="post">
                  <input type="hidden" name="dest" value="<?php echo $val['Place']; ?>">
                  <button type="submit" class="cardbutton" name="direction" value="<?php echo $val['Node_no']; ?>">Direction</button> 
                 </form>
                </div>
             </div>
      </div>
      <script>
        document.querySelector(".edu").style.background ="#a99ee6" ;
        document.querySelector(".edu").style.text ="white" ;
      </script>
      <?php
    }
  }
}

else if(isset($_REQUEST['all']))
{
  ?>
<div class="file_heading2">
  <i>Results after applying filter for "All Places": </i>
  <hr style="width:100%;color:black;">

</div>
  <?php
$sql="select * from recommend order by Rating desc;";
$result=$conn1->query($sql);
if($result->num_rows>0)
{
  foreach($result as $key => $val)
  { 
    {?>

    <div class="card col-md-3">
        <img src="<?php echo "images/".$val['Place_image']; ?>" >
            <div class="container"> 
            <center>
            <div class="addcon">
              <h5><b><?php echo $val['Place']; ?></b></h5> 
    </div>
              <p style="font-size:11px; line-height:14px;"><?php echo $val['Place_address']; ?></p>
               <div class="rating-container">
             <p style="font-size:15px; line-height:16px;"><?php echo "Rating: ".$val['Rating']; ?></p>
              </div>
              
             <div class="button-container">
                <form action="gsearch.php" method="post"> 
                <button type="submit" class="cardbutton" name="serkey" value="<?php echo $val['Search_key']; ?>">More Info</button>&nbsp;&nbsp;&nbsp;
                </form>

                <form action="rec_optimize.php" method="post">
                <input type="hidden" name="dest" value="<?php echo $val['Place']; ?>">
                <button type="submit" class="cardbutton" name="direction" value="<?php echo $val['Node_no']; ?>">Direction</button> 
                </form>
              </div>
        
           </div>
    </div>
    <script>
        document.querySelector(".all").style.background ="#a99ee6";
        document.querySelector(".all").style.text ="white" ;
      </script>


    <?php
     }
    
   }
  }
}

else{?>
<div class="file_heading2">
  <i>Top 10 recommended places:</i>
  <hr style="width:100%;color:black;">

</div>
  <?php
  $sql="select * from recommend order by Rating desc;";
  $result=$conn1->query($sql);
  if($result->num_rows>0)
  {
    foreach($result as $key => $val)
    { 
      if ($counter == 10)
       {
        break;
       }
       else{?>
  
      <div class="card col-md-3">
          <img src="<?php echo "images/".$val['Place_image']; ?>" >
              <div class="container"> 
              <div class="addcon">
                <h5><b><?php echo $val['Place']; ?></b></h5> 
       </div>
                <p style="font-size:11px; line-height:14px;"><?php echo $val['Place_address']; ?></p>
       
                 <div class="rating-container">
               <p style="font-size:15px;  line-height:16px;"><?php echo "Rating: ".$val['Rating']; ?></p>
                </div>
                
               <div class="button-container">
                  <form action="gsearch.php" method="post"> 
                  <button type="submit" class="cardbutton" name="serkey" value="<?php echo $val['Search_key']; ?>">More Info</button>&nbsp;&nbsp;&nbsp;
                  </form>

                  <form action="rec_optimize.php" method="post">
                  <input type="hidden" name="dest" value="<?php echo $val['Place']; ?>">
                  <button type="submit" class="cardbutton" name="direction" value="<?php echo $val['Node_no']; ?>">Direction</button> 
                  </form>
                </div>
             </div>
      </div>
      <!-- <script>
        document.querySelector(".edu").style.background ="#adc9ed";
      </script> -->
      <?php
       }
       $counter++;
     }
    }

}

?>
  </div>
  
</div> 
    
</body>

</html>

